InfeKt-FM1 - rescue through the chip's update mode (rescue/)

When?
- A newer FM-1 with the UC25HQ80 flash chip that still runs InfeKt/Viral 1.11 or older: those versions cannot update
  themselves there (the installer page reports "0 requests").
- An FM-1 that no longer starts.
Not needed otherwise: the stock firmware and InfeKt 1.12 or later update normally with infekt-fm1.html.

The tools
- fm1_infekt_uboot.py: writes InfeKt from firmware/ (only the firmware area; the bootloader and the device data stay
  untouched). Tested on a UC25HQ80 unit.
- fm1_rescue.py: puts M-VAVE's stock firmware back. Needs M-VAVE's .fwsc files (m-vave.com, PC firmware); only V15
  and V16 are accepted. It may refuse on newer units whose bootloader matches neither (then nothing is written).
  Linux and macOS only.
- Both first read the whole flash and save it as a backup: fm1-backup-YYYYMMDD-HHMMSS.bin in the folder of the .fwsc
  file (keep it!). On their first start both download the flash loader (wl82loader.bin) from the internet (checked by
  SHA-256).

Update mode
- FM-1 off, hold REC, switch on: the screen shows "UPDATE MODE (REC)". Connect it with a USB data cable directly to
  the computer. The device shows up as 4C4A:8057 "UBOOT".

Linux / macOS (Terminal, in the unzipped installer folder)
  python3 -m venv ~/fm1-rescue && ~/fm1-rescue/bin/pip install pyusb libusb-package
  sudo ~/fm1-rescue/bin/python rescue/fm1_infekt_uboot.py firmware/infekt-fm1-1.19.16-multi-ble.fwsc
      -> check + backup, writes nothing. Ends with "check passed"? Then:
  sudo ~/fm1-rescue/bin/python rescue/fm1_infekt_uboot.py firmware/infekt-fm1-1.19.16-multi-ble.fwsc --write
      -> writes, reads everything back, restarts the FM-1.
  The stock firmware instead of InfeKt (M-VAVE's files):
  sudo ~/fm1-rescue/bin/python rescue/fm1_rescue.py V15.fwsc V16.fwsc            (check)
  sudo ~/fm1-rescue/bin/python rescue/fm1_rescue.py V15.fwsc V16.fwsc --write    (write)

Windows (Command Prompt, in the unzipped installer folder; no sudo)
  1. Start Zadig (zadig.akeo.ie) while the FM-1 is connected in update mode: Options > List All Devices, choose the
     device 4C4A:8057 "UBOOT", driver WinUSB, "Install Driver".
  2. py -m venv %USERPROFILE%\fm1-rescue
     %USERPROFILE%\fm1-rescue\Scripts\pip install pyusb libusb-package
  3. %USERPROFILE%\fm1-rescue\Scripts\python rescue\fm1_infekt_uboot.py firmware\infekt-fm1-1.19.16-multi-ble.fwsc
     %USERPROFILE%\fm1-rescue\Scripts\python rescue\fm1_infekt_uboot.py firmware\infekt-fm1-1.19.16-multi-ble.fwsc --write
  (fm1_rescue.py does not run on Windows: use Linux or macOS for it.)

If it stops: just start it again (the FM-1 stays in update mode). Keep the whole output and the backup file and send
them along if you report a problem.
