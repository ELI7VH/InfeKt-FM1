InfeKt-FM1 1.19 by J0KERPACK
=========================

A virtual analog synthesizer firmware for the M-VAVE FM-1: three oscillators per voice, two multimode filters, three
LFOs, a modulation matrix, effects with reverb, delay and Particles Shimmer, two parts (layer or split), arpeggiator,
Hybrid Sequencer, drum machine, MIDI over USB, Bluetooth and the TRS jack. Runs on both FM-1 hardware versions,
including the newer one.

Unofficial. Not affiliated with or endorsed by M-VAVE or by the manufacturer of the original; all trademarks belong
to their owners.


What is in this folder
----------------------
  infekt-fm1.html                      the installer, editor and patch manager (opens in the browser, no server)
  firmware/infekt-fm1-1.19-multi-ble.fwsc   the firmware
  firmware/m-bootloader-1.2.fwsc       the optional bootloader (MIT, with its licence beside it)
  InfeKt-FM1_Quickstart_EN.pdf         the two-page guide (English)
  InfeKt-FM1_Quickstart_DE.pdf         the same in German
  rescue/                              rescue tools for an FM-1 that does not start (README-RESCUE.txt)
  waves/                               the command-line tool for your own oscillator waves (README.md)
  LICENSES/, CREDITS.txt, SOURCE.txt   licences, credits, where the source of the platform code is
  LIESMICH.txt                         this file in German


Install
-------
You need: a computer with Chrome or Edge (other browsers cannot talk to the FM-1 over MIDI), a USB *data* cable
(some cables only charge) and your FM-1, switched on and plugged in directly.

1. Unzip this folder. Double-click infekt-fm1.html. It opens in your browser; no internet connection is needed.
   The page starts in German: the "English" button at the top switches it (and remembers it).
2. Click Connect and allow MIDI (with SysEx) when the browser asks.
3. BACK UP FIRST. If your FM-1 already runs InfeKt-FM1, save your banks on the Patches tab (patch manager:
   "Back up all banks") before you install. The factory banks option below overwrites banks A and B.
4. Installation tab: two options are ticked:
     - Install factory banks (into banks A and B)
     - Install Sete's wavetables (nine waves, WAVE 2 to WAVE 10)
   Untick them to keep what you have there. Both can be installed later from the Patches and Wavetables tabs.
5. Click Install. Do not pull the cable until the page says it is done. The FM-1 restarts as InfeKt-FM1.

The same installer is on the website: https://j0kerpack.github.io/InfeKt-FM1/install.html Back to the stock firmware: bottom of the Installation tab.


The guide
---------
InfeKt-FM1_Quickstart_EN.pdf (two pages), the Guide tab inside infekt-fm1.html and
https://j0kerpack.github.io/InfeKt-FM1/guide.html


If something goes wrong
-----------------------
Start the installer again: an interrupted install can be finished. An FM-1 that no longer starts, or a newer FM-1
(flash chip UC25HQ80) still running InfeKt 1.11 or older: see rescue/README-RESCUE.txt.


Website and downloads: https://j0kerpack.github.io/InfeKt-FM1/ (repository: https://github.com/j0kerpack/InfeKt-FM1)


Support
-------
Want to support this project? https://ko-fi.com/j0kerpack


Credits and licences
--------------------
Firmware and page by J0KERPACK. The platform layer is fm1-base and felucca-bsp (MPL-2.0; Charles Vestal, Leo
Kuroshita and others), the Bluetooth libraries and package files are JieLi's AC79 SDK (Apache-2.0), the optional
bootloader is m-bootloader by Julius Vitkauskas (MIT), the display font is Barlow Semi Condensed (SIL OFL 1.1).
Factory sounds by Manuel Schleis (Vengeance Sound), Alan Marcero and Sete; wavetables by Sete.
Details: CREDITS.txt, LICENSES/ and SOURCE.txt. The synthesizer's own source code will follow later.

This software is provided "as is", without warranty of any kind. Installing a firmware is at your own risk.
