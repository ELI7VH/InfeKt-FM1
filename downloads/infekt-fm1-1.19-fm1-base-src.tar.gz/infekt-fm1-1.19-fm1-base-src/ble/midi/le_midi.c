/* SPDX-License-Identifier: MPL-2.0 AND Apache-2.0
 * Copyright (C) 2026 Charles Vestal (from fm1-ble and fm1-ctl)
 * Portions (the connection handling, advertising set-up and connection-parameter requests) come from the
 * JieLi AC79 SDK's apps/common/ble/le_trans_data.c, Copyright (c) 2011-2016 JIELI (Zhuhai Jieli Technology
 * Co., Ltd.), under the Apache License 2.0 (LICENSES/Apache-2.0.txt). Changed for fm1-ble: the SDK's
 * test profile replaced by the BLE MIDI service, its packet parsing and batching, and the advertising data.
 * The rest is MPL-2.0 (LICENSE). */
/* BLE MIDI peripheral on JieLi's BLE stack: the MIDI service (03B80E5A-EDE8-4B33-A751-6CE34EC4C700) with
 * its one characteristic (7772E5DB-3868-4112-A1A9-F2669D106BF3: read, write without response, notify),
 * advertised with the service UUID and the name "FM-1 1F2D" (ble_midi_name: four hex digits of this FM-1's own).
 * Built on the structure of the SDK's
 * le_trans_data.c (its event handling and connection-parameter requests), without its test profile.
 *
 *   bt_ble_init()                 the stack is up (BT_STATUS_INIT_OK): profile, advertising
 *   ble_midi_send_many(link, pkts, ms, n)   USB-MIDI packets (cin | status << 8 | d1 << 16 | d2 << 24), each
 *                                 with the millisecond it happened, to link 0, the central, as many as fit one
 *                                 notification; returns how many went; from the main loop (the stack's context)
 *   ble_midi_receive(pkt, ts)     the firmware's: every MIDI message written by the central, with the
 *                                 sender's millisecond it happened (13 bits: BLE MIDI's timestamp)
 *   ble_midi_connected(link)      link 0: a central is connected and listens (CCC on); link 1 (BLE_MIDI_CENTRAL):
 *                                 the MIDI device we connected to is ready
 *   ble_midi_sysex_get(&p, &n), ble_midi_sysex_done()   a SysEx message the central wrote (the bytes between F0
 *                                 and F7), for the main loop; done: the next may come (le_sysex.h)
 *   ble_midi_sysex_send(f, n), ble_midi_sysex_pump(ms)   a whole F0 .. F7 frame to the central, in as many
 *                                 notifications as it takes (pump: from the main loop, 1 while it goes out; f is
 *                                 read until then)
 *
 * BLE_MIDI_CENTRAL (fm1.toml ble_central = true): the FM-1 is a central too, at the same time: it scans for
 * MIDI devices (the service in their advertising), connects to the one asked for, finds its MIDI
 * characteristic and subscribes to it; what it notifies arrives as ble_midi_receive on cable 1 (0x10 in byte
 * 0), and ble_midi_send_many(1, ...) writes to it, each link in notifications of its own. The stack then runs
 * both roles (ble_stack_gatt_role 2, the SDK's multi-link calls,
 * one link each: TRANS_MULTI_BLE_EN in its config), after the SDK's apps/common/ble/multi_demo
 * (le_multi_common.c, le_multi_client.c), Copyright (c) JIELI, Apache-2.0.
 *   ble_midi_scan(on)  ble_midi_found(i, name, rssi)  ble_midi_connect(i)  ble_midi_disconnect()
 *   ble_midi_connect_addr(addr, type)   by address, without a scan (an app's automatic reconnection)
 *   ble_midi_device_info(addr, type, name)   the device asked for (to remember it)
 *   ble_midi_central_state()      BLE_MC_* below */
#include "system/app_core.h"
#include "system/includes.h"
#include "app_config.h"
#include "btstack/btstack_task.h"
#include "btstack/bluetooth.h"
#include "btcontroller_modules.h"
#include "bt_common.h"
#include "le_common.h"
#include "third_party/common/ble_user.h"

#define LOG_TAG_CONST       BLE_MIDI
#define LOG_TAG             "[BLE_MIDI]"
#define LOG_INFO_ENABLE
#include "debug.h"
const char log_tag_const_i_BLE_MIDI = 1;           /* the SDK keeps these in log_config; ours here */

#ifndef BLE_MIDI_CENTRAL
#define BLE_MIDI_CENTRAL 0
#endif
extern void ble_midi_receive(uint32_t pkt, uint32_t ts);   /* ts: the sender's millisecond (13 bits) */
extern uint32_t shim_ms(void);
extern void ble_midi_name(char *name);              /* "FM-1 " + four hex digits: this FM-1's (device/radio.c) */

/* ---- the GATT database (the SDK's binary form: size, flags, handle, uuid, value). Flags: bit 1 read,
 * bit 2 write without response, bit 3 write, bit 4 notify, 0x100 dynamic, 0x200 128-bit uuid. */
#define MIDI_SVC_UUID  0x00, 0xC7, 0xC4, 0x4E, 0xE3, 0x6C, 0x51, 0xA7, 0x33, 0x4B, 0xE8, 0xED, 0x5A, 0x0E, 0xB8, 0x03
#define MIDI_CHR_UUID  0xF3, 0x6B, 0x10, 0x9D, 0x66, 0xF2, 0xA9, 0xA1, 0x12, 0x41, 0x68, 0x38, 0xDB, 0xE5, 0x72, 0x77
#define H_NAME  0x0003
#define H_MIDI  0x0006
#define H_CCC   0x0007
static const uint8_t profile_data[] = {
    /* 0x0001 primary service 1800 (GAP) */
    0x0a, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x28, 0x00, 0x18,
    /* 0x0002 characteristic 2a00 (device name) read, dynamic; 0x0003 its value */
    0x0d, 0x00, 0x02, 0x00, 0x02, 0x00, 0x03, 0x28, 0x02, 0x03, 0x00, 0x00, 0x2a,
    0x08, 0x00, 0x02, 0x01, 0x03, 0x00, 0x00, 0x2a,
    /* 0x0004 primary service MIDI */
    0x18, 0x00, 0x02, 0x00, 0x04, 0x00, 0x00, 0x28, MIDI_SVC_UUID,
    /* 0x0005 characteristic MIDI: read | write without response | write | notify (0x1e); 0x0006 its value */
    0x1b, 0x00, 0x02, 0x00, 0x05, 0x00, 0x03, 0x28, 0x1e, 0x06, 0x00, MIDI_CHR_UUID,
    0x16, 0x00, 0x1e, 0x03, 0x06, 0x00, MIDI_CHR_UUID,
    /* 0x0007 client characteristic configuration */
    0x0a, 0x00, 0x0a, 0x01, 0x07, 0x00, 0x02, 0x29, 0x00, 0x00,
    0x00, 0x00,
};

#define ADV_INTERVAL_MIN     (160)              /* 0.625 ms units: 100 ms (the SDK demo: 500 ms) */
#define ATT_LOCAL_MTU_SIZE   (64)
#define ATT_SEND_CBUF_SIZE   (512 * (1 + BLE_MIDI_CENTRAL))   /* both links share it with the central */
#define ATT_RAM_BUFSIZE      (ATT_CTRL_BLOCK_SIZE + ATT_LOCAL_MTU_SIZE + ATT_SEND_CBUF_SIZE)
static u8 att_ram_buffer[ATT_RAM_BUFSIZE] __attribute__((aligned(4)));

static char gap_device_name[10];                 /* "FM-1 1F2D" (bt_ble_init): two FM-1s on one computer told apart */
#define GAP_NAME_LEN 9u
#define GAP_NAME_SHORT 4u                        /* "FM-1": what the advertising holds, its full name in the scan response */
#if BLE_MIDI_CENTRAL
#define ROLE_SERVER 0                            /* the SDK's MULTI_ROLE_SLAVE / MASTER */
#define ROLE_CLIENT 1
#define SEND(h, att, d, n, op) ble_op_multi_att_send_data((h), (att), (d), (n), (op))
#define CCC_GET(h, att) multi_att_get_ccc_config((h), (att))
#define CCC_SET(h, att, v) multi_att_set_ccc_config((h), (att), (v))
#else
#define SEND(h, att, d, n, op) ble_op_att_send_data((att), (d), (n), (op))
#define CCC_GET(h, att) att_get_ccc_config(att)
#define CCC_SET(h, att, v) att_set_ccc_config((att), (v))
#endif
static volatile hci_con_handle_t con_handle;
static u8 adv_data[ADV_RSP_PACKET_MAX], scan_rsp_data[ADV_RSP_PACKET_MAX];
static u8 ble_work_state, adv_ctrl_en;
static OS_MUTEX mutex;

/* connection parameters: ask for a short interval (MIDI latency and jitter): Apple's 11.25-15 ms for
 * MIDI first, then the SDK demo's */
static const uint8_t connection_update_enable = 1;
static uint8_t connection_update_cnt;
static const struct conn_update_param_t connection_param_table[] = {
    {9, 21, 0, 400},                /* 11.25..26.25 ms (1.25 ms units; Apple: max >= min + 15 ms), 4 s timeout */
    {9, 12, 0, 400},                /* 11.25..15 ms (BLE MIDI's own advice) */
    {12, 24, 0, 400},               /* 15..30 ms */
    {16, 32, 0, 400},
};
#define CONN_PARAM_TABLE_CNT (sizeof(connection_param_table) / sizeof(connection_param_table[0]))

/* 1 while the central retries a device that does not answer (an automatic reconnection, already said once): the
 * advertising's own lines stay off the log, so a series of failed attempts folds into one line there */
static u8 mc_hush;

static void set_ble_work_state(ble_state_e state)
{
    if (state != ble_work_state) {
        if (!mc_hush)
            log_info("ble_work_st:%x->%x\n", ble_work_state, state);
        ble_work_state = state;
    }
}
static ble_state_e get_ble_work_state(void) { return ble_work_state; }

static void send_request_connect_parameter(u8 table_index)
{
    const struct conn_update_param_t *param = &connection_param_table[table_index];
    log_info("update_request:-%d-%d-%d-%d-\n", param->interval_min, param->interval_max, param->latency, param->timeout);
    if (con_handle)
        ble_op_conn_param_request(con_handle, (void *)param);
}
static void check_connetion_updata_deal(void)
{
    if (connection_update_enable && connection_update_cnt < CONN_PARAM_TABLE_CNT)
        send_request_connect_parameter(connection_update_cnt);
}
static void connection_update_complete_success(u8 *packet)
{
    int conn_interval = hci_subevent_le_connection_update_complete_get_conn_interval(packet);
    int conn_latency = hci_subevent_le_connection_update_complete_get_conn_latency(packet);
    int conn_timeout = hci_subevent_le_connection_update_complete_get_supervision_timeout(packet);
    printf("conn: interval %d latency %d\n", conn_interval, conn_latency);   /* 1.25 ms units, on the log */
}

/* ---- SysEx (the central's link only; le_sysex.h): one message in at a time, its buffer in the pool (RAM's .bss is
 * full in some builds); one frame out at a time, sent from the caller's buffer (plat_sysex_send pumps it out before it
 * returns: no copy) */
#include "le_sysex.h"
static lsx_rx_t lsx __attribute__((section(".pool.lsx")));   /* (not .pool: a lent build keeps the radio's
                                                               * .pool first, hybrid build_variant.py --lend) */
static struct { const u8 *f; u32 n, pos; } lsx_out;
int ble_midi_sysex_get(const u8 **p, u32 *n)
{
    if (!lsx.ready) return 0;
    *p = lsx.buf;
    *n = lsx.n;
    return 1;
}
void ble_midi_sysex_done(void) { lsx.ready = 0; }

/* ---- MIDI in: a BLE MIDI packet is a header, then (timestamp, message) pairs with running status */
static int midi_len(u8 st)                       /* data bytes of a status byte; -1 for sysex */
{
    switch (st & 0xF0) {
    case 0x80: case 0x90: case 0xA0: case 0xB0: case 0xE0: return 2;
    case 0xC0: case 0xD0: return 1;
    case 0xF0:
        switch (st) {
        case 0xF1: case 0xF3: return 1;
        case 0xF2: return 2;
        case 0xF0: return -1;
        default: return 0;                       /* F6, F7, F8..FF */
        }
    }
    return 0;
}
static u8 cin_of(u8 st, int n)
{
    if (st >= 0xF8) return 0xF;                  /* realtime */
    if (st < 0xF0) return st >> 4;
    return n == 2 ? 3 : n == 1 ? 2 : 5;          /* system common */
}
static void midi_parse(const u8 *b, u16 len, u32 cable)   /* cable: 0 the central's, 0x10 the device's */
{
    u16 i = 1;
    u8 st = 0, hi = b[0] & 0x3F, lo = 0, seen = 0;  /* the time: the header's high six bits, each message's low seven */
    u32 ts = 0;
    while (i < len) {
        if (lsx.in && !cable) {                  /* inside a SysEx message (begun in this packet or one before) */
            int done;
            u8 rt;
            i = (u16)lsx_body(&lsx, b, i, len, &done, &rt);
            if (rt)
                ble_midi_receive(cable | 0xFu | (uint32_t)rt << 8, ts);
            if (done)
                st = 0;                          /* (SysEx ends running status) */
            continue;
        }
        if (b[i] & 0x80) {                       /* a timestamp low byte, then maybe a status */
            u8 l = b[i] & 0x7F;
            if (seen && l < lo)                  /* (lower than the one before: the next 128 ms) */
                hi = (u8)((hi + 1u) & 0x3Fu);
            lo = l;
            seen = 1;
            ts = (u32)hi << 7 | lo;
            i++;
            if (i < len && (b[i] & 0x80))
                st = b[i++];
        }
        if (!st)
            return;
        {
            int n = midi_len(st), k;
            u8 d[2] = {0, 0};
            if (n < 0) {                         /* sysex: the central's gathered (lsx), the device's skipped */
                if (!cable) {
                    lsx_start(&lsx);
                    st = 0;
                    continue;
                }
                while (i < len && !(b[i] & 0x80))
                    i++;
                continue;
            }
            if (st >= 0xF8) {
                ble_midi_receive(cable | 0xFu | (uint32_t)st << 8, ts);
                continue;
            }
            for (k = 0; k < n; k++) {
                if (i >= len || (b[i] & 0x80))
                    return;
                d[k] = b[i++];
            }
            ble_midi_receive(cable | (uint32_t)cin_of(st, n) | (uint32_t)st << 8 | (uint32_t)d[0] << 16 |
                             (uint32_t)d[1] << 24, ts);
        }
    }
}

/* ---- MIDI out: as many messages as fit one packet (header, then timestamp + message each) */
#if BLE_MIDI_CENTRAL
static volatile hci_con_handle_t mc_handle;      /* the device we connected to */
static u16 mc_value;                             /* its MIDI characteristic's value handle (0: not found yet) */
static volatile u8 mc_state;
static u16 mc_mtu = 20;                          /* its ATT payload, as send_mtu is the central's */
static int mc_ready(void) { return mc_handle && mc_value && mc_state == 4; }
#else
static int mc_ready(void) { return 0; }
#endif
static int periph_ready(void) { return con_handle && CCC_GET(con_handle, H_CCC); }
int ble_midi_connected(int link) { return link ? mc_ready() : periph_ready(); }
int ble_midi_peripheral_connected(void) { return periph_ready(); }
int ble_midi_peripheral_linked(void) { return con_handle != 0; }   /* listening or not yet */
static u16 send_mtu = 20;                        /* ATT payload: 23 - 3 until the exchange says more */
static u32 remain_max[2];                        /* each link's stack buffer when empty (the most seen) */
int ble_midi_send_many(int link, const uint32_t *pkts, const uint16_t *ms, int n)
{
    /* each message carries the millisecond it happened (ms[], 13 bits): a receiver that honours the
     * timestamps (CoreMIDI does) replays the original timing, however the radio bunched the packets.
     * Within one packet the times may not go backwards and span under 128 ms (the header holds the
     * first's high bits; a low byte smaller than the one before means the next 128 ms). */
    u8 buf[64], run = 0;
    u32 len = 0, remain = 0, t0, tp, mtu = send_mtu;
    int i;
    if (!ble_midi_connected(link) || n <= 0)
        return 0;
    /* one notification in the stack at a time (a link's: each has its own buffer in the multi-link stack): the
     * radio sends about one a connection interval, so what piles up meanwhile goes together in the next one
     * (with its own timestamps) instead of as a queue of small ones that each wait for a slot */
#if BLE_MIDI_CENTRAL
    ble_op_multi_att_get_remain(link ? mc_handle : con_handle, &remain);
    if (link)
        mtu = mc_mtu;
#else
    ble_op_att_get_remain(&remain);
#endif
    if (remain > remain_max[link])
        remain_max[link] = remain;
    if (remain < remain_max[link] || remain < 8u)
        return 0;
    t0 = tp = ms[0] & 0x1FFFu;
    buf[len++] = (u8)(0x80 | ((t0 >> 7) & 0x3F));
    for (i = 0; i < n; i++) {
        u8 st = (u8)(pkts[i] >> 8), cin = pkts[i] & 0xF, m[4];
        u32 k = 0, t = ms[i] & 0x1FFFu;
        if (((t - tp) & 0x1FFFu) > 4096u)        /* earlier than the one before: as late as it */
            t = tp;
        if (((t - t0) & 0x1FFFu) > 120u)         /* the rest in the next packet */
            break;
        /* running status (channel messages only): the same status at the same time needs neither the
         * timestamp nor the status again, a new time only the timestamp */
        if (st < 0xF0 && st == run && i) {
            if (t != tp)
                m[k++] = (u8)(0x80 | (t & 0x7F));
        } else {
            m[k++] = (u8)(0x80 | (t & 0x7F));
            m[k++] = st;
        }
        if (cin == 0xF || cin == 5) {
        } else if (cin == 2 || cin == 0xC || cin == 0xD) {
            m[k++] = (u8)(pkts[i] >> 16);
        } else {
            m[k++] = (u8)(pkts[i] >> 16);
            m[k++] = (u8)(pkts[i] >> 24);
        }
        if (len + k > mtu || len + k > sizeof buf)
            break;
        memcpy(buf + len, m, k);
        len += k;
        tp = t;
        if (st < 0xF0)
            run = st;
        else if (st < 0xF8)
            run = 0;                             /* system common ends running status; real time does not */
    }
    if (i == 0)
        return 0;
#if BLE_MIDI_CENTRAL
    if (link)
        return SEND(mc_handle, mc_value, buf, len, ATT_OP_WRITE_WITHOUT_RESPOND) ? 0 : i;
#endif
    return SEND(con_handle, H_MIDI, buf, len, ATT_OP_AUTO_READ_CCC) ? 0 : i;
}

/* a frame to the central (F0 .. F7), sent from f: the caller keeps it until ble_midi_sysex_pump says it went (or gives
 * it up: ble_midi_sysex_send(0, 0)). 0 queued, -1 not (another going, no central listening) */
int ble_midi_sysex_send(const u8 *f, u32 n)
{
    if (!f) {
        lsx_out.pos = lsx_out.n = 0;
        return 0;
    }
    if (lsx_out.pos < lsx_out.n || n < 2u || !periph_ready())
        return -1;
    lsx_out.f = f;
    lsx_out.n = n;
    lsx_out.pos = 0;
    return 0;
}
/* main loop: the frame's next packets, as many as the stack takes now (as ble_midi_send_many: one notification in its
 * buffer at a time); 1 while some of it is still to go (the link's other MIDI waits: nothing may come between) */
int ble_midi_sysex_pump(u32 ms)
{
    u8 buf[64];
    u32 remain = 0, len, round;
    if (lsx_out.pos >= lsx_out.n)
        return 0;
    if (!periph_ready()) {
        lsx_out.pos = lsx_out.n;                 /* (the central gone: dropped) */
        return 0;
    }
    for (round = 0; round < 4u && lsx_out.pos < lsx_out.n; round++) {
#if BLE_MIDI_CENTRAL
        ble_op_multi_att_get_remain(con_handle, &remain);
#else
        ble_op_att_get_remain(&remain);
#endif
        if (remain > remain_max[0])
            remain_max[0] = remain;
        if (remain < remain_max[0] || remain < 8u)
            break;
        {
            u32 pos = lsx_out.pos;
            len = lsx_packet(buf, send_mtu < sizeof buf ? send_mtu : sizeof buf, lsx_out.f, lsx_out.n, &pos, ms & 0x1FFFu);
            if (!len || SEND(con_handle, H_MIDI, buf, len, ATT_OP_AUTO_READ_CCC))
                break;                           /* (the stack full: the same packet next poll) */
            lsx_out.pos = pos;
        }
    }
    return lsx_out.pos < lsx_out.n;
}

/* ---- ATT */
static uint16_t att_read_callback(hci_con_handle_t connection_handle, uint16_t att_handle, uint16_t offset, uint8_t *buffer, uint16_t buffer_size)
{
    uint16_t len = 0;
    switch (att_handle) {
    case H_NAME:
        len = GAP_NAME_LEN;
        if (offset >= len || offset + buffer_size > len)
            break;
        if (buffer) {
            memcpy(buffer, &gap_device_name[offset], buffer_size);
            len = buffer_size;
        }
        break;
    case H_MIDI:                                 /* the spec: a read returns nothing */
        len = 0;
        break;
    case H_CCC:
        if (buffer) {
            buffer[0] = (uint8_t)CCC_GET(connection_handle, att_handle);
            buffer[1] = 0;
        }
        len = 2;
        break;
    }
    return len;
}
static int att_write_callback(hci_con_handle_t connection_handle, uint16_t att_handle, uint16_t transaction_mode, uint16_t offset, uint8_t *buffer, uint16_t buffer_size)
{
    switch (att_handle) {
    case H_CCC:
        set_ble_work_state(BLE_ST_NOTIFY_IDICATE);
        check_connetion_updata_deal();
        log_info("ccc %02x\n", buffer[0]);
        CCC_SET(connection_handle, att_handle, buffer[0]);
        break;
    case H_MIDI:
        if (buffer_size >= 2)
            midi_parse(buffer, buffer_size, 0);
        break;
    }
    return 0;
}

#if BLE_MIDI_CENTRAL
/* ---- the central: MIDI devices around, one connected (after the SDK's le_multi_client.c)
 *
 * The device's set-up, step by step (mc_step while mc_state is SEARCHING), each step on the radio's log ("dev ..."
 * lines: their first five characters differ from step to step, as the log folds a line into the one before when
 * those match):
 *   link up            "dev link <handle> <interval>ms"
 *   the search         the stack finds every service, characteristic and the descriptors of each characteristic that
 *                      notifies or indicates: "dev svc <start>-<end>", "dev midi chr <value>-<end> p<properties>",
 *                      then its CCC (uuid 0x2902) within the characteristic's handles: "dev ccc <handle>" ("guessed":
 *                      none reported, the value's handle + 1, as before). 5 s at most from the link
 *   the read           the MIDI characteristic read once (BLE MIDI's step; some devices only send after it): "dev read
 *                      ok", "dev read err <att error>" or "dev read: no answer" (2 s); on with the CCC either way
 *   the CCC write      notifications on (0x0001; 0x0002 when it can only indicate), answered or not: "dev write ccc",
 *                      once more after 2 s without an answer ("dev retry ccc"), then given up ("dev drop")
 *   pairing            only when the write (or the read) is refused for security (ATT 0x05, 0x08, 0x0C, 0x0F): Just
 *                      Works on this link alone ("dev pair asked"), then "dev encrypted" and the write again; 10 s at
 *                      most. Never asked up front (an OXI E16 refuses pairing)
 *   ready              the write answered without an error: "dev READY", advertising again; "dev first midi in" with
 *                      the first notification
 *   the end            "dev gone <reason> in <step>" (HCI reason: 0x08 supervision timeout, 0x13 the device let go,
 *                      0x16 we did, 0x3E never established) */
enum { BLE_MC_OFF, BLE_MC_SCANNING, BLE_MC_CONNECTING, BLE_MC_SEARCHING, BLE_MC_READY };   /* mc_state */
enum { MC_SEARCH, MC_READ, MC_CCC, MC_PAIR, MC_DROP };                                      /* mc_step */
static const char *const mc_step_name[] = {"search", "read", "ccc", "pair", "drop"};
#define MC_MAX 8
typedef struct { char name[21]; u8 addr[6], addr_type; s8 rssi; } mc_dev_t;
static mc_dev_t mc_dev[MC_MAX];
static volatile u8 mc_n;
static u8 search_ram_buffer[512] __attribute__((aligned(4)));
static struct create_conn_param_t mc_conn;
static u8 mc_tries;                              /* connection attempts left (0x3E: the device never answered) */
static u32 mc_t0;                                /* when the connection was asked for (it has no timeout of its own) */
static u32 mc_t1;                                /* when the step began */
#define MC_CCC_MAX 8
static u16 mc_end, mc_props, mc_ccc, mc_read_len;   /* the MIDI characteristic's last handle, properties, its CCC */
static u16 mc_ccc_at[MC_CCC_MAX];                /* the CCCs the search reported (any characteristic's) */
static u8 mc_ccc_n, mc_step, mc_writes, mc_read_done, mc_paired, mc_rx_seen, mc_svc_seen;
static u8 mc_auto_said;                          /* an automatic attempt said on the log, not yet anything since */
static u8 mc_cancelled;                          /* a connection we cancelled: the stack's failure event for it is ours */
static u8 mc_reenc;                              /* the stack began encrypting this link with a bond it keeps (a device
                                                  * that forgot it never answers: the search stalls until the bond goes) */
static char mc_name[21];                         /* the device asked for (its scan name; "" when asked by address) */
static void bt_ble_adv_enable(u8 enable);
static void mc_create(void)                      /* advertising paused meanwhile: its slots can crowd out the link's first */
{
    bt_ble_adv_enable(0);
    mc_state = BLE_MC_CONNECTING;
    mc_t0 = shim_ms();
    mc_cancelled = 0;
    ble_op_create_connection(&mc_conn);
}
static const u8 midi_svc_le[16] = {MIDI_SVC_UUID}, midi_chr_le[16] = {MIDI_CHR_UUID};

static int uuid_is(const u8 *u, const u8 *le)    /* a 128-bit uuid as the stack reports it, either order */
{
    int i, fwd = 1, rev = 1;
    for (i = 0; i < 16; i++) {
        fwd &= u[i] == le[i];
        rev &= u[i] == le[15 - i];
    }
    return fwd || rev;
}

/* an advertising report: a device advertising the MIDI service goes in the list (its name from this report or
 * its scan response; the strongest reading kept) */
static void mc_adv(const adv_report_t *r)
{
    const u8 *d = r->data;
    u8 len = r->length, i = 0, midi = 0, nl = 0, k;
    const u8 *name = 0;
    while (i + 1u < len) {
        u8 l = d[i], t = d[i + 1];
        if (!l || i + 1u + l > len)
            break;
        if ((t == 0x06 || t == 0x07) && l >= 17)                 /* 128-bit service uuids */
            for (k = 0; k + 16u <= (u8)(l - 1); k += 16)
                midi |= (u8)uuid_is(&d[i + 2 + k], midi_svc_le);
        if (t == 0x08 || t == 0x09) {                            /* the name */
            name = &d[i + 2];
            nl = (u8)(l - 1);
        }
        i = (u8)(i + 1 + l);
    }
    for (k = 0; k < mc_n; k++)
        if (!memcmp(mc_dev[k].addr, r->address, 6))
            break;
    if (r->event_type == 1u && k == mc_n && mc_n < MC_MAX) {   /* directed at us (ADV_DIRECT_IND, no data): a device that
                                                                  * bonded with the FM-1 asks for it after its own
                                                                  * power-on, and advertises nothing else (an SMK-25 II) */
        memset(&mc_dev[k], 0, sizeof mc_dev[k]);
        memcpy(mc_dev[k].addr, r->address, 6);
        mc_dev[k].addr_type = r->address_type;
        mc_dev[k].rssi = r->rssi;
        memcpy(mc_dev[k].name, "(DIRECT)", 9);
        mc_n++;
        printf("dev direct adv %02x%02x%02x%02x%02x%02x t%d\n", r->address[5], r->address[4], r->address[3],
               r->address[2], r->address[1], r->address[0], r->address_type);
        return;
    }
    if (k == mc_n) {
        if (!midi || mc_n >= MC_MAX)
            return;                                              /* (a scan response alone does not add one) */
        memset(&mc_dev[k], 0, sizeof mc_dev[k]);
        memcpy(mc_dev[k].addr, r->address, 6);
        mc_dev[k].addr_type = r->address_type;
        mc_dev[k].rssi = r->rssi;
        mc_n++;
    }
    if (name) {
        if (nl > 20)
            nl = 20;
        memcpy(mc_dev[k].name, name, nl);
        mc_dev[k].name[nl] = 0;
    }
    if (r->rssi > mc_dev[k].rssi)
        mc_dev[k].rssi = r->rssi;
}

void ble_midi_scan(int on)                       /* main loop: start (the list starts empty) or stop scanning */
{
    if (on && mc_state == BLE_MC_OFF) {
        mc_n = 0;
        ble_op_set_scan_param(SCAN_ACTIVE, 48, con_handle ? 8 : 48);   /* 30 ms interval; a 5 ms window (0.625 ms) with
                                                                  * a computer's link up, the radio free for it; else
                                                                  * all of it (a bonded device's directed advertising
                                                                  * after its power-on lasts ~1.3 s: missed otherwise) */
        ble_op_scan_enable2(1, 0);
        mc_state = BLE_MC_SCANNING;
    } else if (!on && mc_state == BLE_MC_SCANNING) {
        ble_op_scan_enable2(0, 0);
        mc_state = BLE_MC_OFF;
    }
}
int ble_midi_found(int i, char *name, int *rssi)   /* device i of the scan: 0 when there is none */
{
    if (i < 0 || i >= mc_n)
        return 0;
    if (name) {
        const char *s = mc_dev[i].name[0] ? mc_dev[i].name : "MIDI device";
        int k;
        for (k = 0; k < 20 && s[k]; k++)
            name[k] = s[k];
        name[k] = 0;
    }
    if (rssi)
        *rssi = mc_dev[i].rssi;
    return 1;
}
static void mc_start(const u8 *addr, u8 type)
{
    mc_conn.conn_interval = 24;                  /* 30 ms (1.25 ms units), as the SDK's; the device may ask for less */
    mc_conn.conn_latency = 0;
    mc_conn.supervision_timeout = 400;           /* 4 s */
    mc_conn.peer_address_type = type;
    memcpy(mc_conn.peer_address, addr, 6);
    mc_tries = 3;
    mc_create();
}
int ble_midi_connect(int i)                      /* connect to device i of the scan */
{
    if (i < 0 || i >= mc_n || mc_handle || (mc_state != BLE_MC_SCANNING && mc_state != BLE_MC_OFF))
        return -1;
    if (mc_state == BLE_MC_SCANNING)
        ble_op_scan_enable2(0, 0);
    ble_midi_found(i, mc_name, 0);
    mc_hush = 0;
    mc_auto_said = 0;
    printf("dev connect %s\n", mc_name);
    mc_start(mc_dev[i].addr, mc_dev[i].addr_type);
    return 0;
}
static void mc_hex(char *b, const u8 *a)         /* an address as 12 hex digits, its last byte first */
{
    int i;
    for (i = 0; i < 6; i++) {
        b[2 * i] = "0123456789abcdef"[a[5 - i] >> 4];
        b[2 * i + 1] = "0123456789abcdef"[a[5 - i] & 15];
    }
    b[12] = 0;
}
/* connect to a device by its address (as ble_midi_device_info gives it) and type, without a scan: the app's
 * automatic reconnection. The first of a series of attempts is said on the log; while they fail the same way the
 * rest stay quiet (mc_hush), and their "dev no answer" lines fold into one */
int ble_midi_connect_addr(const u8 *addr, int type)
{
    char b[13];
    if (!addr || mc_handle || mc_state != BLE_MC_OFF)
        return -1;
    mc_name[0] = 0;
    if (mc_auto_said) {
        mc_hush = 1;
    } else {
        mc_auto_said = 1;
        mc_hex(b, addr);
        printf("dev auto %s t%d\n", b, type);
    }
    mc_start(addr, (u8)type);
    return 0;
}
/* the device asked for, connecting or connected: its address, type and name ("" when asked by address); 0 = none */
int ble_midi_device_info(u8 *addr, int *type, char *name)
{
    if (mc_state == BLE_MC_OFF || mc_state == BLE_MC_SCANNING)
        return 0;
    if (addr)
        memcpy(addr, mc_conn.peer_address, 6);
    if (type)
        *type = mc_conn.peer_address_type;
    if (name)
        memcpy(name, mc_name, 21);
    return 1;
}
void ble_midi_disconnect(void)
{
    if (mc_handle) {
        printf("dev hang up\n");
        ble_op_disconnect(mc_handle);
    } else if (mc_state == BLE_MC_CONNECTING) {
        mc_cancelled = 1;
        ble_op_create_connection_cancel();
        mc_state = BLE_MC_OFF;
        bt_ble_adv_enable(1);                    /* (the cancel's own failure event no longer does it) */
        mc_hush = 0;
    }
}

/* a bond the device no longer has: deleted, so the next attempt connects without encryption (an SMK-25 II that was
 * paired before stalled every search after "pairing 1", the stack's encryption with the old key) */
static void mc_forget_bond(void)
{
    if (!mc_reenc)
        return;
    mc_reenc = 0;
    {   /* (the list may hold it under another address type than the one connected by: each tried; none: all go,
         * the device would stall every attempt otherwise) */
        u8 t, ok = 0;
        for (t = 0; t < 4u && !ok; t++)
            ok = (u8)ble_list_delete_device(mc_conn.peer_address, (u8)((mc_conn.peer_address_type + t) & 3u));
        if (!ok)
            ok = (u8)(ble_list_clear_all() ? 2u : 0u);
        printf("dev bond cleared %d\n", (int)ok);
    }
}
void ble_midi_forget_all(void)                  /* every bond the radio keeps (GLO's FORGET) */
{
    printf("dev bonds cleared %d\n", (int)ble_list_clear_all());
}

/* the set-up's steps */
static void mc_drop(const char *why, int code)   /* given up: said, then disconnected (again 3 s on, if still up) */
{
    printf("dev drop: %s %x\n", why, code);
    mc_step = MC_DROP;
    mc_t1 = shim_ms();
    if (mc_handle)
        ble_op_disconnect(mc_handle);
}
static void mc_ccc_write(void)                   /* notifications on (indications when it can only indicate) */
{
    static u16 v;                                /* (the stack copies it into its queue; kept all the same) */
    v = (mc_props & ATT_PROPERTY_INDICATE) && !(mc_props & ATT_PROPERTY_NOTIFY) ? 2 : 1;
    mc_step = MC_CCC;
    mc_t1 = shim_ms();
    printf(mc_writes ? "dev retry ccc %x=%d\n" : "dev write ccc %x=%d\n", mc_ccc, v);
    mc_writes++;
    if (SEND(mc_handle, mc_ccc, (u8 *)&v, 2, ATT_OP_WRITE))
        printf("dev queue full (ccc)\n");        /* (the 2 s wait then tries again) */
}
static void mc_read(void)                        /* the MIDI characteristic read once */
{
    static u16 dummy;                            /* (a read takes no data; the queue wants some) */
    mc_step = MC_READ;
    mc_t1 = shim_ms();
    mc_read_len = 0;
    if (SEND(mc_handle, mc_value, (u8 *)&dummy, 2, ATT_OP_READ)) {
        printf("dev queue full (read)\n");
        mc_read_done = 1;
        mc_ccc_write();
    }
}
static void mc_next(void)                        /* after the search, or after pairing: the read, then the CCC */
{
    mc_writes = 0;
    if ((mc_props & ATT_PROPERTY_READ) && !mc_read_done)
        mc_read();
    else
        mc_ccc_write();
}
static int mc_security(u8 att)                   /* ATT errors that pairing (encryption) may cure */
{
    return att == 0x05 || att == 0x08 || att == 0x0C || att == 0x0F;
}
static void mc_pair(u8 att)                      /* refused for security: pair (Just Works) on this link, once */
{
    if (mc_paired) {
        mc_drop("refused after pairing", att);
        return;
    }
    mc_paired = 1;
    mc_step = MC_PAIR;
    mc_t1 = shim_ms();
    /* 0x05 (insufficient authentication): the stack's GATT client asks for pairing itself on that error; the others
     * we ask for */
    if (att != 0x05 && !sm_api_request_pairing(mc_handle)) {
        mc_drop("pairing not started", att);
        return;
    }
    printf("dev pair asked (att %x)\n", att);
}
static void mc_encryption(u8 status, u8 on)      /* the link's encryption changed */
{
    if (status || !on) {
        printf("dev encrypt failed %x\n", status);
        if (mc_step == MC_PAIR)
            mc_drop("not encrypted", status);
        return;
    }
    printf("dev encrypted\n");
    if (mc_state == BLE_MC_SEARCHING && mc_step == MC_PAIR)
        mc_next();                               /* (the read again too, if it was the one refused) */
}
static void mc_answer(u8 status)                 /* the read's or the CCC write's answer (the stack's QUERY_COMPLETE) */
{
    if (mc_state != BLE_MC_SEARCHING)
        return;                                  /* (READY: the answer to a repeated write) */
    if (mc_step == MC_READ) {
        if (status)
            printf("dev read err %x\n", status);
        else
            printf("dev read ok %d B\n", mc_read_len);
        if (status == 0x05) {                    /* (the stack is pairing already) */
            mc_pair(status);
            return;
        }
        mc_read_done = 1;
        mc_ccc_write();
    } else if (mc_step == MC_CCC) {
        if (!status) {
            mc_state = BLE_MC_READY;
            mc_auto_said = 0;
            printf("dev READY%s\n", mc_paired ? " (paired)" : "");
            bt_ble_adv_enable(1);                /* set up: the computer may find us again */
        } else if (mc_security(status)) {
            mc_pair(status);
        } else {
            mc_drop("ccc refused", status);
        }
    }
}

/* main loop: a connection the device has not answered within 5 s is given up (a device that stopped advertising,
 * or left), and so is a search not done 5 s after the link came up, a read not answered in 2 s (on with the CCC),
 * a CCC write not answered twice 2 s apart, pairing not done in 10 s: the state goes back to off, the app says so */
void ble_midi_poll(void)
{
    u32 now = shim_ms();
    if (mc_state == BLE_MC_CONNECTING && !mc_handle && now - mc_t0 > 5000u) {
        printf("dev no answer\n");
        mc_cancelled = 1;
        ble_op_create_connection_cancel();
        mc_state = BLE_MC_OFF;
        bt_ble_adv_enable(1);
        mc_hush = 0;
    } else if (mc_state == BLE_MC_SEARCHING && mc_handle) {
        switch (mc_step) {
        case MC_SEARCH:
            if (now - mc_t0 > 5000u) {
                mc_forget_bond();
                mc_drop("search timed out", 0);
            }
            break;
        case MC_READ:
            if (now - mc_t1 > 2000u) {
                printf("dev read: no answer\n");
                mc_read_done = 1;
                mc_ccc_write();
            }
            break;
        case MC_CCC:
            if (now - mc_t1 > 2000u) {
                if (mc_writes < 2)
                    mc_ccc_write();
                else
                    mc_drop("ccc: no answer", 0);
            }
            break;
        case MC_PAIR:
            if (now - mc_t1 > 10000u)
                mc_drop("pairing timed out", 0);
            break;
        default:                                 /* MC_DROP: still up */
            if (now - mc_t1 > 3000u) {
                mc_t1 = now;
                ble_op_disconnect(mc_handle);
            }
            break;
        }
    }
}
int ble_midi_central_state(void) { return mc_state; }

/* the stack's search: each characteristic as found (with its service), then (void *)-1 at the end */
void user_client_report_search_result(search_result_t *r)
{
    if (r == (void *)-1) {
        int k;
        if (!mc_handle || mc_state != BLE_MC_SEARCHING)
            return;
        if (!mc_value) {
            mc_drop("no MIDI characteristic", 0);
            return;
        }
        mc_ccc = 0;
        for (k = 0; k < mc_ccc_n && !mc_ccc; k++)    /* its CCC: the one within its handles */
            if (mc_ccc_at[k] > mc_value && mc_ccc_at[k] <= mc_end)
                mc_ccc = mc_ccc_at[k];
        if (mc_ccc) {
            printf("dev ccc %x\n", mc_ccc);
        } else {
            mc_ccc = (u16)(mc_value + 1);        /* none reported: the descriptor after the value, as most have it */
            printf("dev ccc %x guessed\n", mc_ccc);
        }
        mc_next();
        return;
    }
    if (!r->services.uuid16 && !mc_svc_seen && uuid_is(r->services.uuid128, midi_svc_le)) {
        mc_svc_seen = 1;
        printf("dev svc %x-%x\n", r->services.start_group_handle, r->services.end_group_handle);
    }
    if (!mc_value && !r->characteristic.uuid16 && uuid_is(r->characteristic.uuid128, midi_chr_le)) {
        mc_value = r->characteristic.value_handle;
        mc_end = r->characteristic.end_handle;
        mc_props = r->characteristic.properties;
        printf("dev midi chr %x-%x p%x\n", mc_value, mc_end, mc_props);
    }
}
/* the search's descriptors, after all the characteristics (those of each one that notifies or indicates): the CCCs
 * kept, the MIDI characteristic's picked at the end by its handles */
void user_client_report_descriptor_result(charact_descriptor_t *d)
{
    if (d->uuid16 == 0x2902 && mc_ccc_n < MC_CCC_MAX)
        mc_ccc_at[mc_ccc_n++] = d->handle;
}
/* after the search the stack reports here: notifications, a read's value, and each request's end (QUERY_COMPLETE:
 * blob[0] its ATT status, value_handle the handle asked) */
void user_client_report_data_callback(att_data_report_t *d)
{
    if (!mc_handle || d->conn_handle != mc_handle)
        return;
    switch (d->packet_type) {
    case GATT_EVENT_NOTIFICATION:                /* the device's MIDI */
    case GATT_EVENT_INDICATION:
        if (d->value_handle == mc_value && d->blob_length >= 2) {
            if (!mc_rx_seen) {
                mc_rx_seen = 1;
                printf("dev first midi in (%d B)\n", d->blob_length);
            }
            midi_parse(d->blob, d->blob_length, 0x10u);
        }
        break;
    case GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT:
        if (mc_step == MC_READ)
            mc_read_len = d->blob_length;
        break;
    case GATT_EVENT_QUERY_COMPLETE:
        mc_answer(d->blob_length ? d->blob[0] : 0);
        break;
    }
}
int l2cap_connection_update_request_just(u8 *packet, hci_con_handle_t handle) { (void)packet; (void)handle; return 0; }

static void client_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    if (packet_type != HCI_EVENT_PACKET)
        return;
    switch (hci_event_packet_get_type(packet)) {
    case GAP_EVENT_ADVERTISING_REPORT:
        if (mc_state == BLE_MC_SCANNING)
            mc_adv((const adv_report_t *)&packet[2]);
        break;
    case HCI_EVENT_LE_META:
        switch (hci_event_le_meta_get_subevent_code(packet)) {
        case HCI_SUBEVENT_LE_CONNECTION_COMPLETE:
            if (hci_subevent_le_connection_complete_get_role(packet))
                break;                           /* a central connected to us: the server's */
            if (packet[3]) {
                if (mc_cancelled) {              /* the one we cancelled (no answer, or let go): said and done */
                    mc_cancelled = 0;
                    if (packet[3] != 0x02)
                        printf("dev cancel %x\n", packet[3]);
                    break;
                }
                printf("dev link failed %x\n", packet[3]);
                mc_state = BLE_MC_OFF;
                bt_ble_adv_enable(1);
                mc_hush = 0;
                break;
            }
            /* advertising stays paused until the search is done: a computer that connected meanwhile (a Mac that
             * remembered the FM-1) stalled it, and the device never got as far as MIDI */
            mc_handle = hci_subevent_le_connection_complete_get_connection_handle(packet);
            mc_t0 = mc_t1 = shim_ms();
            mc_value = mc_end = mc_props = mc_ccc = 0;
            mc_ccc_n = mc_writes = mc_read_done = mc_paired = mc_rx_seen = mc_svc_seen = 0;
            mc_step = MC_SEARCH;
            mc_cancelled = 0;
            mc_reenc = 0;
            mc_mtu = 20;
            mc_hush = 0;
            mc_auto_said = 0;
            printf("dev link %x %dms\n", mc_handle,
                   hci_subevent_le_connection_complete_get_conn_interval(packet) * 5 / 4);
            ble_op_multi_att_send_conn_handle(mc_handle, 0, ROLE_CLIENT);
            user_client_init(mc_handle, search_ram_buffer, sizeof search_ram_buffer);
            mc_state = BLE_MC_SEARCHING;
            ble_op_search_profile_all();
            break;
        case HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE:
            if (mc_handle && little_endian_read_16(packet, 4) == mc_handle)
                printf("dev interval %dms\n",
                       hci_subevent_le_connection_update_complete_get_conn_interval(packet) * 5 / 4);
            break;
        }
        break;
    case HCI_EVENT_ENCRYPTION_CHANGE:            /* status, handle, on */
        if (mc_handle && little_endian_read_16(packet, 3) == mc_handle)
            mc_encryption(packet[2], packet[5]);
        break;
    case HCI_EVENT_ENCRYPTION_KEY_REFRESH_COMPLETE:   /* status, handle: encrypted again with new keys */
        if (mc_handle && little_endian_read_16(packet, 3) == mc_handle)
            mc_encryption(packet[2], 1);
        break;
    case HCI_EVENT_DISCONNECTION_COMPLETE:
        if (!mc_handle || little_endian_read_16(packet, 3) != mc_handle)
            break;
        printf("dev gone %x in %s\n", packet[5], mc_state == BLE_MC_READY ? "ready" : mc_step_name[mc_step]);
        if (mc_state != BLE_MC_READY)
            mc_forget_bond();                    /* (lost while setting up after the old key was tried) */
        ble_op_multi_att_send_conn_handle(0, 0, ROLE_CLIENT);
        mc_handle = 0;
        mc_value = 0;
        if (packet[5] == 0x3E && mc_state != BLE_MC_READY && mc_tries && --mc_tries) {
            printf("dev again (%d left)\n", mc_tries);
            mc_create();                         /* never established: try again */
            break;
        }
        mc_state = BLE_MC_OFF;
        bt_ble_adv_enable(1);
        mc_hush = 0;
        break;
    case ATT_EVENT_MTU_EXCHANGE_COMPLETE:
        if (little_endian_read_16(packet, 2) == mc_handle) {
            u16 mtu = att_event_mtu_exchange_complete_get_MTU(packet) - 3;
            ble_op_multi_att_set_send_mtu(mc_handle, mtu);
            mc_mtu = (u16)(mtu > 64 ? 64 : mtu);
        }
        break;
    }
}

/* one HCI handler for both roles: each event to the role it belongs to (le_multi_common.c's way) */
static void cbk_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size);
static void both_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    int to_server = 1, to_client = 1;
    if (packet_type == HCI_EVENT_PACKET) {
        switch (hci_event_packet_get_type(packet)) {
        case GAP_EVENT_ADVERTISING_REPORT:
            to_server = 0;
            break;
        case HCI_EVENT_LE_META:
            if (hci_event_le_meta_get_subevent_code(packet) == HCI_SUBEVENT_LE_CONNECTION_COMPLETE ||
                hci_event_le_meta_get_subevent_code(packet) == HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE) {
                int slave = hci_subevent_le_connection_complete_get_role(packet);
                to_server = slave;
                to_client = !slave;
            }
            break;
        }
    }
    if (to_server)
        cbk_packet_handler(packet_type, channel, packet, size);
    if (to_client)
        client_packet_handler(packet_type, channel, packet, size);
}
#endif

/* ---- advertising */
static int make_set_adv_data(void)
{
    static const u8 svc[16] = {MIDI_SVC_UUID};
    u8 offset = 0, *buf = adv_data;
    offset += make_eir_packet_val(&buf[offset], offset, HCI_EIR_DATATYPE_FLAGS, 0x06, 1);
    offset += make_eir_packet_data(&buf[offset], offset, HCI_EIR_DATATYPE_COMPLETE_128BIT_SERVICE_UUIDS, (void *)svc, 16);
    /* 31 bytes: the flags and the service leave 8 for a name, so "FM-1" shortened here; a computer's scan reads
     * the whole name from the scan response */
    offset += make_eir_packet_data(&buf[offset], offset, HCI_EIR_DATATYPE_SHORTENED_LOCAL_NAME, (void *)gap_device_name, GAP_NAME_SHORT);
    if (offset > ADV_RSP_PACKET_MAX)
        return -1;
    if (!mc_hush)
        log_info("adv_data(%d)\n", offset);
    ble_op_set_adv_data(offset, buf);
    return 0;
}
static int make_set_rsp_data(void)
{
    u8 offset = 0, *buf = scan_rsp_data;
    offset += make_eir_packet_data(&buf[offset], offset, HCI_EIR_DATATYPE_COMPLETE_LOCAL_NAME, (void *)gap_device_name, GAP_NAME_LEN);
    ble_op_set_rsp_data(offset, buf);
    return 0;
}
static void advertisements_setup_init(void)
{
    ble_op_set_adv_param(ADV_INTERVAL_MIN, ADV_IND, ADV_CHANNEL_ALL);
    if (make_set_adv_data() | make_set_rsp_data())
        puts("advertisements_setup_init fail\n");
}
static int set_adv_enable(void *priv, u32 en)
{
    ble_state_e next_state = en ? BLE_ST_ADV : BLE_ST_IDLE, cur_state;
    if ((!adv_ctrl_en && en) || (en && con_handle))
        return APP_BLE_OPERATION_ERROR;
    cur_state = get_ble_work_state();
    switch (cur_state) {
    case BLE_ST_ADV: case BLE_ST_IDLE: case BLE_ST_INIT_OK: case BLE_ST_NULL: case BLE_ST_DISCONN:
        break;
    default:
        return APP_BLE_OPERATION_ERROR;
    }
    if (cur_state == next_state)
        return APP_BLE_NO_ERROR;
    if (!mc_hush)
        log_info("adv_en:%d\n", en);
    set_ble_work_state(next_state);
    if (en)
        advertisements_setup_init();
    ble_op_adv_enable(en);
    return APP_BLE_NO_ERROR;
}
static void bt_ble_adv_enable(u8 enable) { set_adv_enable(0, enable); }

/* ---- the stack's events */
static void server_profile_start(u16 handle)
{
#if BLE_MIDI_CENTRAL
    ble_op_multi_att_send_conn_handle(handle, 0, ROLE_SERVER);
#else
    ble_op_att_send_init(handle, att_ram_buffer, ATT_RAM_BUFSIZE, ATT_LOCAL_MTU_SIZE);
#endif
    set_ble_work_state(BLE_ST_CONNECT);
}
static void cbk_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    int mtu;
    u32 tmp;
    u8 status;
    if (packet_type != HCI_EVENT_PACKET)
        return;
    switch (hci_event_packet_get_type(packet)) {
    case ATT_EVENT_CAN_SEND_NOW:
        break;
    case HCI_EVENT_LE_META:
        switch (hci_event_le_meta_get_subevent_code(packet)) {
        case HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE:
            if (BLE_MIDI_CENTRAL && !hci_subevent_le_enhanced_connection_complete_get_role(packet))
                break;                           /* we are the central on this one */
            status = hci_subevent_le_enhanced_connection_complete_get_status(packet);
            if (status) {
                log_info("connection fail %x\n", status);
                set_ble_work_state(BLE_ST_DISCONN);
                break;
            }
            con_handle = hci_subevent_le_enhanced_connection_complete_get_connection_handle(packet);
            printf("computer: connected (enh) %x\n", con_handle);
            server_profile_start(con_handle);
            break;
        case HCI_SUBEVENT_LE_CONNECTION_COMPLETE:
            if (BLE_MIDI_CENTRAL && !hci_subevent_le_connection_complete_get_role(packet))
                break;                           /* we are the central on this one */
            if (packet[3])
                break;                           /* failed */
            con_handle = hci_subevent_le_connection_complete_get_connection_handle(packet);
            printf("computer: connected %x\n", con_handle);
            connection_update_complete_success(packet + 8);
            server_profile_start(con_handle);
            break;
        case HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE:
            if (little_endian_read_16(packet, 4) == con_handle)
                connection_update_complete_success(packet);
            break;
        }
        break;
    case HCI_EVENT_DISCONNECTION_COMPLETE:
        if (little_endian_read_16(packet, 3) != con_handle)
            break;
        printf("computer: disconnected %x\n", packet[5]);
#if BLE_MIDI_CENTRAL
        multi_att_clear_ccc_config(con_handle);
        ble_op_multi_att_send_conn_handle(0, 0, ROLE_SERVER);
        con_handle = 0;
#else
        con_handle = 0;
        ble_op_att_send_init(con_handle, 0, 0, 0);
#endif
        set_ble_work_state(BLE_ST_DISCONN);
        os_mutex_pend(&mutex, 0);
#if BLE_MIDI_CENTRAL
        if (mc_state != BLE_MC_CONNECTING && mc_state != BLE_MC_SEARCHING)   /* (the central resumes it when done) */
#endif
            bt_ble_adv_enable(1);
        os_mutex_post(&mutex);
        connection_update_cnt = 0;
        break;
    case ATT_EVENT_MTU_EXCHANGE_COMPLETE:
        if (little_endian_read_16(packet, 2) != con_handle)
            break;
        mtu = att_event_mtu_exchange_complete_get_MTU(packet) - 3;
        log_info("ATT MTU = %u\n", mtu);
#if BLE_MIDI_CENTRAL
        ble_op_multi_att_set_send_mtu(con_handle, mtu);
#else
        ble_op_att_set_send_mtu(mtu);
#endif
        send_mtu = (u16)(mtu > 64 ? 64 : mtu);
        break;
    case L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_RESPONSE:
        if (little_endian_read_16(packet, 2) != con_handle)
            break;
        tmp = little_endian_read_16(packet, 4);
        printf("conn param %d: %s\n", connection_update_cnt, tmp ? "refused" : "accepted");   /* on the log */
        if (tmp) {
            connection_update_cnt++;
            check_connetion_updata_deal();
        } else {
            connection_update_cnt = CONN_PARAM_TABLE_CNT;
        }
        break;
    case HCI_EVENT_ENCRYPTION_CHANGE:
        printf("encryption %d on %x\n", packet[2], little_endian_read_16(packet, 3));
        break;
    }
}

static void cbk_sm_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size)
{
    if (packet_type != HCI_EVENT_PACKET)
        return;
    switch (hci_event_packet_get_type(packet)) {
    case SM_EVENT_JUST_WORKS_REQUEST:
        sm_just_works_confirm(sm_event_just_works_request_get_handle(packet));
        log_info("sm: just works\n");
        break;
    case SM_EVENT_PASSKEY_DISPLAY_NUMBER:
    case SM_EVENT_PASSKEY_DISPLAY_CANCEL:
    case SM_EVENT_PASSKEY_INPUT_NUMBER:
        break;
    case SM_EVENT_PAIR_PROCESS: {                /* on the log: 1 reconnect, 2 key missing, 3 failed, 4 timeout, 5 encryption failed */
        sm_just_event_t *e = (void *)packet;
        printf("pairing %x on %x\n", e->data[0], e->con_handle);
#if BLE_MIDI_CENTRAL
        if (mc_handle && e->con_handle == mc_handle && e->data[0] == SM_EVENT_PAIR_SUB_RECONNECT_START)
            mc_reenc = 1;
#endif
#if BLE_MIDI_CENTRAL
        if (mc_handle && e->con_handle == mc_handle && mc_state == BLE_MC_SEARCHING && mc_step == MC_PAIR &&
            (e->data[0] == SM_EVENT_PAIR_SUB_PAIR_FAIL || e->data[0] == SM_EVENT_PAIR_SUB_PAIR_TIMEOUT ||
             e->data[0] == SM_EVENT_PAIR_SUB_ENCRYPTION_FAIL))
            mc_drop("pairing failed", e->data[0]);   /* the pairing asked for after a refusal did not come off */
#endif
        break;
    }
    }
}

void ble_profile_init(void)
{
    printf("ble profile init (MIDI)\n");
    le_device_db_init();
    sm_init();
    sm_set_io_capabilities(IO_CAPABILITY_NO_INPUT_NO_OUTPUT);
    sm_set_authentication_requirements(SM_AUTHREQ_BONDING);
    sm_set_encryption_key_size_range(7, 16);
    sm_set_request_security(0);                  /* MIDI needs no pairing; a central may still ask */
#if BLE_MIDI_CENTRAL
    /* as a central: no pairing asked for (BLE MIDI needs none; an OXI E16 refuses it, and the service search did
     * not survive the attempt); Just Works if a device asks, and again when it remembers a bond we lost */
    sm_set_master_io_capabilities(IO_CAPABILITY_NO_INPUT_NO_OUTPUT);
    sm_set_master_request_pair(0);
    sm_set_master_pair_redo(1);
#endif
    sm_event_callback_set(&cbk_sm_packet_handler);
#if BLE_MIDI_CENTRAL
    ble_stack_gatt_role(2);                      /* server and client */
#endif
    att_server_init(profile_data, att_read_callback, att_write_callback);
    att_server_register_packet_handler(cbk_packet_handler);
#if BLE_MIDI_CENTRAL
    gatt_client_init();
    gatt_client_register_packet_handler(client_packet_handler);
    hci_event_callback_set(&both_packet_handler);
    le_l2cap_register_packet_handler(&both_packet_handler);
    ble_vendor_set_default_att_mtu(ATT_LOCAL_MTU_SIZE);
    ble_op_multi_att_send_init(att_ram_buffer, ATT_RAM_BUFSIZE, ATT_LOCAL_MTU_SIZE);
#else
    hci_event_callback_set(&cbk_packet_handler);
    le_l2cap_register_packet_handler(&cbk_packet_handler);
    ble_vendor_set_default_att_mtu(ATT_LOCAL_MTU_SIZE);
#endif
}

void bt_ble_init(void)
{
    log_info("ble init (MIDI)\n");
    ble_midi_name(gap_device_name);
    if (!os_mutex_valid(&mutex))
        os_mutex_create(&mutex);
    set_ble_work_state(BLE_ST_INIT_OK);
    os_mutex_pend(&mutex, 0);
    adv_ctrl_en = 1;
    bt_ble_adv_enable(1);
    os_mutex_post(&mutex);
}
/* Bluetooth switched off or on by the player (the stack stays up): off ends every link, stops advertising and
 * scanning, so the radio goes quiet; on advertises again */
void ble_midi_enable(int on)
{
    os_mutex_pend(&mutex, 0);
    if (on) {
        adv_ctrl_en = 1;
        bt_ble_adv_enable(1);
        os_mutex_post(&mutex);
        return;
    }
    os_mutex_post(&mutex);
#if BLE_MIDI_CENTRAL
    ble_midi_scan(0);
    ble_midi_disconnect();
#endif
    bt_ble_exit();
}

void bt_ble_exit(void)
{
    os_mutex_pend(&mutex, 0);
    if (con_handle) {
        adv_ctrl_en = 0;
        ble_op_disconnect(con_handle);
    } else {
        bt_ble_adv_enable(0);
        adv_ctrl_en = 0;
    }
    os_mutex_post(&mutex);
}
u16 bt_ble_is_connected(void) { return con_handle; }
