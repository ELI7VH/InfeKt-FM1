# Your own oscillator waves for the InfeKt-FM1

With this tool you load your own waveforms into the FM-1's wave slots **2 to 63**. A wave is a single cycle of a
waveform as a WAV file ("single cycle"). A slot without a wave of yours keeps playing its factory wave. Patches store
only the wave's number: a patch with wave 12 sounds with your wave 12.

The tool comes twice, both do the same:

- **`../infekt-fm1.html`**, tab "Wavetables": a web page for Chrome or Edge. Just double-click the file, no server is
  needed.
- **`vfwaves.py`**: a Python program for the command line (also for many files at once).

The connection is MIDI SysEx, over the USB cable or over Bluetooth MIDI. (German: `LIESMICH.md`.)

## What happens to your WAV file

1. The file is read. Any length and any sample rate, mono or stereo (stereo is mixed to mono), 16, 24 or 32 bit or
   float.
2. The DC offset is removed.
3. The first **64 harmonics** (amplitude and phase) are computed by an FFT over the whole cycle. The length does not
   have to be a power of two: the Fourier transform over exactly one cycle gives the harmonics exactly for any length.
   A cycle of fewer than 130 samples has fewer than 64 harmonics; the rest stays silent.
4. The level is set as the factory waves' is: the wave's peak at full scale, as the sine's. A wave of yours is
   therefore about as loud as the factory waves. `--trim` (in dB) adjusts it.
5. The 64 harmonics, a name (up to 10 characters) and the trim go to the FM-1. There they are kept in flash, also
   after switching off and after firmware updates.

What the FM-1 plays is the wave made of these 64 harmonics, not the file itself. The preview shows both on top of each
other. Very sharp edges get a little rounder and small overshoots. That is so for every band-limited wave, and in
return there is no aliasing in high registers.

## File names

`W12_glass.wav` goes to slot 12 and is called "glass". The number after the `W` is the slot, the rest after `_` the
name. Files without such a name go in order from the slot you give.

## The web page (`infekt-fm1.html`, tab "Wavetables")

1. Open `infekt-fm1.html` (at the top of this folder) in **Chrome** or **Edge** (double-click), tab "Wavetables".
   Firefox and Safari cannot do Web MIDI with SysEx.
2. Click **Connect** and allow MIDI access (SysEx is needed). With several MIDI devices choose the FM-1 in the list.
   It then shows which slots already hold waves of yours.
3. Drag WAV files into the field. For each file you see a preview: grey the original, coloured the version made of
   64 harmonics. Slot and name can still be changed.
4. **Send to the FM-1** sends all waves. The FM-1 shows each one briefly, e.g. "WAVE 12 LOADED glass".
5. Under "Waves in the FM-1": save a slot as WAV (factory waves too), save all 62, reset a slot or all to the factory
   wave.

## The command line (`vfwaves.py`)

Needs Python 3 with `numpy`, for MIDI also `mido` and `python-rtmidi`, for the preview `matplotlib`:

    pip install numpy mido python-rtmidi matplotlib

Examples:

    python3 vfwaves.py ports                              # list the MIDI ports
    python3 vfwaves.py send W12_glass.wav                 # slot 12 (from the file name)
    python3 vfwaves.py send saw.wav --slot 12 --name SAW1 # slot and name given
    python3 vfwaves.py send a.wav b.wav c.wav --slot 20   # slots 20, 21, 22
    python3 vfwaves.py send my_waves/                     # every W<nn>_<name>.wav in the folder
    python3 vfwaves.py send W12_glass.wav --trim -2       # 2 dB quieter than the rule
    python3 vfwaves.py list                               # which slots hold waves of yours
    python3 vfwaves.py dump 12 --out waves/               # slot 12 back as a WAV
    python3 vfwaves.py dump all --out waves/              # all 62 (yours and factory waves)
    python3 vfwaves.py clear 12                           # slot 12 back to its factory wave
    python3 vfwaves.py clear all                          # all back to factory waves
    python3 vfwaves.py plot W12_glass.wav                 # preview as PNG (original and 64 harmonics)

`--port NAME` chooses the MIDI port (a part of the name is enough). Without it the FM-1 is searched for.
`--syx FILE` writes the messages into a `.syx` file instead of sending them, e.g. for another SysEx program.
`decode ANSWERS.syx --out waves/` turns recorded answers of the FM-1 (dumps) into WAV files.

The WAV files read back have 2048 samples per cycle (32-bit float, with `--bits 16` 16 bit) and can be sent again.

## Good to know

- Each wave takes a fraction of a second to transfer. The tool waits for the FM-1's acknowledgement each time and
  compares the checksum of what is in flash.
- You can load while you play. Sounding notes get the new wave between two audio blocks. About every 13th wave the
  FM-1 erases a flash sector; the sound drops out briefly then, as when a patch is saved.
- Use only one tool at a time (not USB and Bluetooth together).
- Over Bluetooth everything takes a little longer: a dump takes about 0.3 s.
- The waves are not part of a patch. If you share a patch that uses a wave of yours, share the WAV file with it.
