#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""vfwaves.py: the InfeKt-FM1's user oscillator waves 2-63 (firmware 0.90, docs/waves-user.md).

Single-cycle WAV files in, 64 harmonics out (DC removed, the first 64 harmonics by FFT of the whole cycle, the level
as the factory waves': the peak at full scale), sent to the FM-1 over MIDI SysEx (USB or Bluetooth MIDI), or written
to a .syx file. The bank can be read back into WAV files. See README.md (English) and LIESMICH.md (German).

  python3 vfwaves.py ports
  python3 vfwaves.py send W12_glass.wav                 # slot from the file name (W12_...)
  python3 vfwaves.py send saw.wav --slot 12 --name SAW1
  python3 vfwaves.py send a.wav b.wav c.wav --slot 20   # slots 20, 21, 22
  python3 vfwaves.py send meine_wellen/                 # every W<nn>_<name>.wav in the folder
  python3 vfwaves.py list                               # which slots hold user waves
  python3 vfwaves.py dump 12 --out wellen/              # slot 12 back as a WAV (factory or user)
  python3 vfwaves.py dump all --out wellen/
  python3 vfwaves.py clear 12 | clear all
  python3 vfwaves.py plot W12_glass.wav                 # the preview: original and its 64-harmonic version (PNG)
  ... --syx out.syx                                     # the messages into a file instead of MIDI
  python3 vfwaves.py decode replies.syx --out wellen/   # dumps in a SysEx file (answers) to WAV files

MIDI needs mido with a backend (python-rtmidi): pip install mido python-rtmidi. Everything else needs numpy only
(matplotlib for plot).
"""
import argparse
import math
import os
import re
import struct
import sys
import time

import numpy as np

SLOT_FIRST, SLOT_LAST = 2, 63
NAME_LEN = 10
REC_LEN = 12 + 64 * 4                     # name 10, trim 1, flags 1, 64 x (half amplitude, uint16 phase)
HEAD = [0xF0, 0x7D, 0x56, 0x46]           # 7D the non-commercial id, 56 46 "VF": the former name, Viral-FM1
CMD_HELLO, CMD_WRITE, CMD_CLEAR, CMD_CLEAR_ALL, CMD_READ = 0x01, 0x10, 0x11, 0x12, 0x13
R_HELLO, R_ACK, R_DUMP = 0x41, 0x50, 0x53
STATUS = {0: "ok", 1: "checksum", 2: "length", 3: "flash", 4: "slot", 5: "command"}


# ---- the format ----------------------------------------------------------------------------------------------------
def crc16(b):
    """CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF)"""
    c = 0xFFFF
    for x in b:
        c ^= x << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return c


def crc3(c):
    return [(c >> 14) & 3, (c >> 7) & 0x7F, c & 0x7F]


def pack7(data):
    """each 7 bytes as 8: first a byte of their top bits (bit k: byte k's), then their low 7 bits"""
    out = []
    for i in range(0, len(data), 7):
        g = data[i:i + 7]
        out.append(sum(((b >> 7) & 1) << k for k, b in enumerate(g)))
        out += [b & 0x7F for b in g]
    return out


def unpack7(data, n):
    out, i = [], 0
    while i < len(data) and len(out) < n:
        hi = data[i]
        i += 1
        for k in range(7):
            if i >= len(data) or len(out) >= n:
                break
            out.append(data[i] | ((hi >> k) & 1) << 7)
            i += 1
    if len(out) != n or i != len(data):
        raise ValueError("bad packing")
    return bytes(out)


def half(x):
    return struct.unpack("<H", struct.pack("<e", float(x)))[0]


def unhalf(h):
    return struct.unpack("<e", struct.pack("<H", h))[0]


def clean_name(s):
    s = "".join(c if 32 <= ord(c) < 127 else "_" for c in s)[:NAME_LEN]
    return s


def record(amp, phs, name, trim_db=0.0):
    """the 268-byte record: amp[0..63], phs[0..63] (cycles) of harmonics 1..64"""
    r = bytearray(REC_LEN)
    nm = clean_name(name).ljust(NAME_LEN)
    r[0:NAME_LEN] = nm.encode("ascii")
    r[10] = int(round(max(-12.8, min(12.7, trim_db)) * 10)) & 0xFF
    r[11] = 0
    for n in range(64):
        a = float(amp[n]) if np.isfinite(amp[n]) and amp[n] > 0 else 0.0
        struct.pack_into("<HH", r, 12 + 4 * n, half(min(a, 60000.0)), int(round((phs[n] % 1.0) * 65536)) % 65536)
    return bytes(r)


def parse_record(r):
    name = r[0:NAME_LEN].decode("ascii", "replace").rstrip()
    trim = struct.unpack("b", r[10:11])[0] / 10.0
    amp = np.zeros(64)
    phs = np.zeros(64)
    for n in range(64):
        h, p = struct.unpack_from("<HH", r, 12 + 4 * n)
        a = unhalf(h)
        amp[n] = a if np.isfinite(a) and 0 < a <= 60000 else 0.0
        phs[n] = p / 65536.0
    return amp, phs, name, trim


# ---- messages ------------------------------------------------------------------------------------------------------
def msg(cmd, *args):
    return bytes(HEAD + [cmd] + [a & 0x7F for a in args] + [0xF7])


def msg_write(slot, rec):
    return bytes(HEAD + [CMD_WRITE, slot] + pack7(rec) + crc3(crc16(rec)) + [0xF7])


def msg_clear(slot):
    return msg(CMD_CLEAR, slot)


def msg_clear_all():
    return msg(CMD_CLEAR_ALL, 0x7F)


def msg_read(slot):
    return msg(CMD_READ, slot)


def msg_hello():
    return msg(CMD_HELLO)


def parse_reply(f):
    """a frame F0 .. F7 from the FM-1: a dict, or None (not ours)"""
    f = bytes(f)
    if len(f) < 6 or list(f[:4]) != HEAD or f[-1] != 0xF7:
        return None
    c, a = f[4], f[5:-1]
    if c == R_ACK and len(a) == 6:
        return {"kind": "ack", "cmd": a[0], "slot": a[1], "status": a[2], "crc": a[3] << 14 | a[4] << 7 | a[5]}
    if c == R_HELLO and len(a) >= 12:
        used = [SLOT_FIRST + j * 7 + k for j in range(9) for k in range(7) if a[3 + j] >> k & 1]
        return {"kind": "hello", "version": a[0], "slots": a[1], "first": a[2], "used": used}
    if c == R_DUMP and len(a) >= 5:
        rec = unpack7(list(a[2:-3]), REC_LEN)
        ok = crc16(rec) == (a[-3] << 14 | a[-2] << 7 | a[-1])
        return {"kind": "dump", "slot": a[0], "user": bool(a[1]), "rec": rec, "ok": ok}
    return {"kind": "other", "cmd": c}


def frames(data):
    """the SysEx frames in a byte string (a .syx file)"""
    out, cur = [], None
    for b in data:
        if b == 0xF0:
            cur = [b]
        elif cur is not None:
            cur.append(b)
            if b == 0xF7:
                out.append(bytes(cur))
                cur = None
    return out


# ---- WAV files -----------------------------------------------------------------------------------------------------
def read_wav(path):
    """samples (float, mono) and the rate of a WAV: PCM 8/16/24/32-bit or float 32/64, any channels (mixed to mono)"""
    b = open(path, "rb").read()
    if b[:4] != b"RIFF" or b[8:12] != b"WAVE":
        raise ValueError("%s: not a WAV file" % path)
    i, fmt, data = 12, None, None
    while i + 8 <= len(b):
        cid, n = b[i:i + 4], struct.unpack_from("<I", b, i + 4)[0]
        body = b[i + 8:i + 8 + n]
        if cid == b"fmt ":
            fmt = body
        elif cid == b"data":
            data = body
        i += 8 + n + (n & 1)
    if fmt is None or data is None:
        raise ValueError("%s: no fmt or data chunk" % path)
    tag, ch, rate = struct.unpack_from("<HHI", fmt, 0)
    bits = struct.unpack_from("<H", fmt, 14)[0]
    if tag == 0xFFFE and len(fmt) >= 26:   # WAVE_FORMAT_EXTENSIBLE: the sub-format's first two bytes
        tag = struct.unpack_from("<H", fmt, 24)[0]
    w = bits // 8
    data = data[:len(data) // (w * ch) * w * ch]
    if tag == 3 and bits in (32, 64):
        x = np.frombuffer(data, dtype="<f4" if bits == 32 else "<f8").astype(np.float64)
    elif tag == 1 and bits == 8:
        x = (np.frombuffer(data, dtype=np.uint8).astype(np.float64) - 128) / 128
    elif tag == 1 and bits == 16:
        x = np.frombuffer(data, dtype="<i2").astype(np.float64) / 32768
    elif tag == 1 and bits == 24:
        u = np.frombuffer(data, dtype=np.uint8).reshape(-1, 3).astype(np.int32)
        v = u[:, 0] | u[:, 1] << 8 | u[:, 2] << 16
        x = np.where(v >= 1 << 23, v - (1 << 24), v).astype(np.float64) / (1 << 23)
    elif tag == 1 and bits == 32:
        x = np.frombuffer(data, dtype="<i4").astype(np.float64) / 2147483648.0
    else:
        raise ValueError("%s: format %d with %d bits is not supported" % (path, tag, bits))
    x = x.reshape(-1, ch).mean(axis=1)
    return x, rate


def write_wav(path, y, rate=46875, bits=32):
    y = np.asarray(y, dtype=np.float64)
    if bits == 16:
        d = (np.clip(y, -1, 1) * 32767).round().astype("<i2").tobytes()
        fmt = struct.pack("<HHIIHH", 1, 1, rate, rate * 2, 2, 16)
    else:
        d = y.astype("<f4").tobytes()
        fmt = struct.pack("<HHIIHH", 3, 1, rate, rate * 4, 4, 32)
    with open(path, "wb") as f:
        f.write(b"RIFF" + struct.pack("<I", 4 + 8 + len(fmt) + 8 + len(d)) + b"WAVE")
        f.write(b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(d)) + d)


# ---- analysis and synthesis ----------------------------------------------------------------------------------------
def harmonics(x):
    """a single cycle -> amp[64], phs[64] (harmonics 1..64; y = sum a sin 2 pi (n t + phs)): DC removed, the DFT of
    the whole cycle (numpy's FFT: any length; a power of two is not needed for exact harmonics), the 64-harmonic
    version's peak at 1 (the factory waves' level convention)"""
    x = np.asarray(x, dtype=np.float64)
    if len(x) < 4:
        raise ValueError("a cycle of %d samples is too short" % len(x))
    x = x - x.mean()
    X = np.fft.rfft(x)
    N = len(x)
    amp, phs = np.zeros(64), np.zeros(64)
    top = min(64, len(X) - 1 - (N % 2 == 0))   # (the Nyquist bin of an even length is not a sine)
    for n in range(1, top + 1):
        amp[n - 1] = 2 * abs(X[n]) / N
        phs[n - 1] = (np.angle(X[n]) / (2 * np.pi) + 0.25) % 1.0
    pk = np.abs(synth(amp, phs)).max()
    if pk <= 1e-12:
        raise ValueError("the cycle is silent (or DC only)")
    return amp / pk, phs


def synth(amp, phs, n=2048, top=64):
    t = np.arange(n) / n
    k = np.arange(1, top + 1)
    return (np.asarray(amp)[:top, None] * np.sin(2 * np.pi * (k[:, None] * t[None, :] + np.asarray(phs)[:top, None]))).sum(0)


def engine_wave(rec, n=2048):
    """the wave as the FM-1 builds it from a record: the peak at full scale, then the trim"""
    amp, phs, name, trim = parse_record(rec)
    if not (amp > 0).any():
        amp[0] = 1.0
    y = synth(amp, phs, n)
    return y / max(np.abs(y).max(), 1e-9) * 10 ** (trim / 20), name


def slot_of(path):
    m = re.match(r"[Ww](\d{1,2})(?:[_\- ](.*))?$", os.path.splitext(os.path.basename(path))[0])
    if not m:
        return None, None
    return int(m.group(1)), (m.group(2) or "")


def default_name(path):
    s, nm = slot_of(path)
    if s is not None:
        return nm or "W%02d" % s
    return os.path.splitext(os.path.basename(path))[0]


def plot(path, out=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    x, rate = read_wav(path)
    amp, phs = harmonics(x)
    y = synth(amp, phs, 2048)
    xo = x - x.mean()
    xo = xo / max(np.abs(xo).max(), 1e-12)
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(8, 6))
    a1.plot(np.arange(len(xo)) / len(xo), xo, lw=1.2, label="original (%d samples)" % len(x))
    a1.plot(np.arange(2048) / 2048, y, lw=1.2, label="64 harmonics")
    a1.set_xlabel("cycle")
    a1.set_ylim(-1.15, 1.15)
    a1.legend(loc="upper right", fontsize=9)
    a1.set_title(os.path.basename(path))
    db = 20 * np.log10(np.maximum(amp / max(amp.max(), 1e-12), 1e-5))
    a2.bar(np.arange(1, 65), db + 100, bottom=-100, width=0.7)
    a2.set_xlabel("harmonic")
    a2.set_ylabel("dB")
    a2.set_ylim(-100, 3)
    fig.tight_layout()
    out = out or os.path.splitext(path)[0] + "_preview.png"
    fig.savefig(out, dpi=110)
    return out


# ---- MIDI ----------------------------------------------------------------------------------------------------------
class Link:
    """the FM-1 over MIDI (mido), or a .syx file (out only)"""

    def __init__(self, port=None, syx=None):
        self.syx, self.inp, self.out = None, None, None
        if syx:
            self.syx = open(syx, "wb")
            return
        try:
            import mido
        except ImportError:
            sys.exit("MIDI needs mido and python-rtmidi: pip install mido python-rtmidi (or write a file: --syx FILE)")
        try:
            outs, ins = mido.get_output_names(), mido.get_input_names()
        except Exception as e:                # (mido without its backend)
            sys.exit("MIDI: %s. pip install python-rtmidi (or write a file: --syx FILE)" % e)
        pick = lambda names: next((n for n in names if (port or "fm-1").lower() in n.lower() or
                                   (not port and ("viral" in n.lower() or "infekt" in n.lower()))), None)
        o, i = pick(outs), pick(ins)
        if not o or not i:
            sys.exit("no FM-1 among the MIDI ports (--port NAME); outputs: %s" % ", ".join(outs) or "none")
        self.out, self.inp = mido.open_output(o), mido.open_input(i)
        self.mido = mido

    def send(self, f):
        if self.syx:
            self.syx.write(f)
            return
        self.out.send(self.mido.Message("sysex", data=list(f[1:-1])))

    def wait(self, want, timeout=3.0):
        """the next reply of ours that want(reply) accepts"""
        if self.syx:
            return None
        t0 = time.time()
        while time.time() - t0 < timeout:
            for m in self.inp.iter_pending():
                if m.type == "sysex":
                    r = parse_reply([0xF0] + list(m.data) + [0xF7])
                    if r and want(r):
                        return r
            time.sleep(0.005)
        return None

    def close(self):
        if self.syx:
            self.syx.close()


def ack_of(cmd, slot):
    return lambda r: r["kind"] == "ack" and r["cmd"] == cmd and (slot is None or r["slot"] == slot)


def write_one(link, slot, rec, tries=2):
    for _ in range(tries):
        link.send(msg_write(slot, rec))
        r = link.wait(ack_of(CMD_WRITE, slot), 4.0)
        if link.syx:
            return True
        if r and r["status"] == 0:
            if r["crc"] != crc16(rec):
                print("  slot %d: the FM-1 holds other bytes (CRC %04x, sent %04x)" % (slot, r["crc"], crc16(rec)))
                return False
            return True
        if r:
            print("  slot %d: refused (%s)" % (slot, STATUS.get(r["status"], r["status"])))
            if r["status"] in (2, 4):
                return False
    print("  slot %d: no answer" % slot)
    return False


# ---- commands ------------------------------------------------------------------------------------------------------
def collect(paths, slot):
    """(slot, path, name) for the files given: a folder's W<nn>_*.wav, files with W<nn> names, or --slot on"""
    jobs = []
    files = []
    for p in paths:
        if os.path.isdir(p):
            for f in sorted(os.listdir(p)):
                if f.lower().endswith(".wav") and slot_of(f)[0] is not None:
                    files.append(os.path.join(p, f))
        else:
            files.append(p)
    for k, f in enumerate(files):
        s = slot + k if slot is not None else slot_of(f)[0]
        if s is None:
            sys.exit("%s: no slot (name it W12_name.wav or give --slot)" % f)
        if not SLOT_FIRST <= s <= SLOT_LAST:
            sys.exit("%s: slot %d is outside %d-%d" % (f, s, SLOT_FIRST, SLOT_LAST))
        jobs.append((s, f))
    return jobs


def cmd_send(a):
    jobs = collect(a.files, a.slot)
    link = Link(a.port, a.syx)
    bad = 0
    for s, f in jobs:
        x, rate = read_wav(f)
        amp, phs = harmonics(x)
        name = a.name if a.name and len(jobs) == 1 else default_name(f)
        rec = record(amp, phs, name, a.trim)
        if a.plot:
            plot(f)
        ok = write_one(link, s, rec)
        print("%s slot %2d  %-10s  %s (%d samples, %d Hz)" % ("ok  " if ok else "FAIL", s, clean_name(name), f, len(x), rate))
        bad += not ok
    link.close()
    return 1 if bad else 0


def save_dump(r, out, bits):
    y, name = engine_wave(r["rec"])
    os.makedirs(out, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_\-]+", "_", name).strip("_") or ("user" if r["user"] else "factory")
    p = os.path.join(out, "W%02d_%s.wav" % (r["slot"], safe))
    write_wav(p, y, bits=bits)
    return p


def cmd_dump(a):
    slots = list(range(SLOT_FIRST, SLOT_LAST + 1)) if a.slot == "all" else [int(a.slot)]
    link = Link(a.port, a.syx)
    bad = 0
    for s in slots:
        link.send(msg_read(s))
        r = link.wait(lambda r, s=s: r["kind"] == "dump" and r["slot"] == s)
        if link.syx:
            continue
        if not r or not r["ok"]:
            print("FAIL slot %d: %s" % (s, "no answer" if not r else "checksum"))
            bad += 1
            continue
        print("ok   slot %2d  %-7s  %s" % (s, "user" if r["user"] else "factory", save_dump(r, a.out, a.bits)))
    link.close()
    return 1 if bad else 0


def cmd_decode(a):
    bad = 0
    for f in frames(open(a.file, "rb").read()):
        r = parse_reply(f)
        if not r:
            continue
        if r["kind"] == "dump":
            if not r["ok"]:
                print("FAIL slot %d: checksum" % r["slot"])
                bad += 1
                continue
            print("ok   slot %2d  %-7s  %s" % (r["slot"], "user" if r["user"] else "factory", save_dump(r, a.out, a.bits)))
        elif r["kind"] == "ack":
            print("ack  cmd %02X slot %2d  %s  crc %04x" % (r["cmd"], r["slot"], STATUS.get(r["status"], r["status"]), r["crc"]))
        elif r["kind"] == "hello":
            print("hello version %d, %d slots from %d; user waves in %s" % (r["version"], r["slots"], r["first"], r["used"] or "none"))
    return 1 if bad else 0


def cmd_clear(a):
    link = Link(a.port, a.syx)
    if a.slot == "all":
        link.send(msg_clear_all())
        r = link.wait(ack_of(CMD_CLEAR_ALL, None), 6.0)
        what = "all slots"
    else:
        s = int(a.slot)
        link.send(msg_clear(s))
        r = link.wait(ack_of(CMD_CLEAR, s))
        what = "slot %d" % s
    link.close()
    if link.syx:
        return 0
    ok = r and r["status"] == 0
    print("%s %s: the factory wave%s" % ("ok  " if ok else "FAIL", what, "s" if a.slot == "all" else ""))
    return 0 if ok else 1


def cmd_list(a):
    link = Link(a.port, a.syx)
    link.send(msg_hello())
    r = link.wait(lambda r: r["kind"] == "hello")
    link.close()
    if link.syx:
        return 0
    if not r:
        print("FAIL: no answer (firmware 0.90 or later?)")
        return 1
    print("wave bank version %d: user waves in slots %s" % (r["version"], ", ".join(map(str, r["used"])) or "none"))
    return 0


def cmd_ports(a):
    try:
        import mido
        outs, ins = mido.get_output_names(), mido.get_input_names()
    except Exception as e:
        sys.exit("MIDI: %s. pip install mido python-rtmidi" % e)
    print("out:", ", ".join(outs) or "none")
    print("in: ", ", ".join(ins) or "none")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--port", help="the MIDI port's name (a part of it; default: the FM-1 / InfeKt-FM1)")
    ap.add_argument("--syx", help="write the messages into this .syx file instead of sending them")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("send", help="single-cycle WAVs to slots")
    p.add_argument("files", nargs="+")
    p.add_argument("--slot", type=int, help="the (first) slot, 2-63; else from the file names W<nn>_name.wav")
    p.add_argument("--name", help="the name (one file; else from the file name), 10 characters")
    p.add_argument("--trim", type=float, default=0.0, help="level trim in dB (-12.8 .. 12.7; 0: as the factory waves)")
    p.add_argument("--plot", action="store_true", help="a preview PNG beside each file")
    p.set_defaults(fn=cmd_send)
    p = sub.add_parser("dump", help="slots back as WAV files")
    p.add_argument("slot", help="2-63 or all")
    p.add_argument("--out", default="wellen_dump")
    p.add_argument("--bits", type=int, default=32, choices=(16, 32))
    p.set_defaults(fn=cmd_dump)
    p = sub.add_parser("decode", help="the dumps in a SysEx file (the FM-1's answers) as WAV files")
    p.add_argument("file")
    p.add_argument("--out", default="wellen_dump")
    p.add_argument("--bits", type=int, default=32, choices=(16, 32))
    p.set_defaults(fn=cmd_decode)
    p = sub.add_parser("clear", help="a slot (or all) back to the factory wave")
    p.add_argument("slot", help="2-63 or all")
    p.set_defaults(fn=cmd_clear)
    p = sub.add_parser("list", help="which slots hold user waves")
    p.set_defaults(fn=cmd_list)
    p = sub.add_parser("plot", help="the preview: original and its 64 harmonics (PNG)")
    p.add_argument("file")
    p.add_argument("--out")
    p.set_defaults(fn=lambda a: print(plot(a.file, a.out)) or 0)
    p = sub.add_parser("ports", help="the MIDI ports")
    p.set_defaults(fn=cmd_ports)
    a = ap.parse_args(argv)
    if a.cmd in ("dump", "clear") and a.slot != "all" and not (a.slot.isdigit() and SLOT_FIRST <= int(a.slot) <= SLOT_LAST):
        ap.error("slot: 2-63 or all")
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
