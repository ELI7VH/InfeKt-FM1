# Eigene Oszillator-Wellen für den InfeKt-FM1 (ab Firmware 0.90)

Mit diesem Werkzeug lädst du eigene Wellenformen in die Wellen-Plätze **2 bis 63** des FM-1. Eine Welle ist ein
einzelner Schwingungszyklus als WAV-Datei („Single-Cycle“). Ein Platz ohne eigene Welle spielt weiter die
Werkswelle. Patches merken sich nur die Wellennummer: Ein Patch mit Welle 12 klingt also mit deiner Welle 12.

Es gibt das Werkzeug zweimal, beide können dasselbe:

- **`../infekt-fm1.html`**, Tab „Wavetables“: eine Webseite für Chrome oder Edge. Einfach die Datei doppelklicken,
  ein Server ist nicht nötig.
- **`vfwaves.py`**: ein Python-Programm für die Kommandozeile (auch für viele Dateien auf einmal).

Die Verbindung läuft über MIDI-SysEx, per USB-Kabel oder per Bluetooth-MIDI.

## Was mit deiner WAV-Datei passiert

1. Die Datei wird gelesen. Jede Länge und jede Abtastrate geht, mono oder stereo (stereo wird zu mono gemischt),
   16, 24 oder 32 Bit oder Float.
2. Der Gleichanteil (DC) wird entfernt.
3. Die ersten **64 Harmonischen** (Amplitude und Phase) werden per FFT über den ganzen Zyklus berechnet. Die Länge muss
   dafür keine Zweierpotenz sein: Die Fourier-Transformation über genau einen Zyklus liefert die Harmonischen für jede
   Länge exakt. Ein Zyklus mit weniger als 130 Samples hat weniger als 64 Harmonische; der Rest bleibt dann still.
4. Der Pegel wird wie bei den Werkswellen gesetzt: Die Spitze der Welle liegt bei Vollaussteuerung, wie beim Sinus.
   Eine eigene Welle ist dadurch ungefähr so laut wie die Werkswellen. Mit `--trim` (in dB) kannst du nachregeln.
5. Die 64 Harmonischen, ein Name (bis 10 Zeichen) und der Trim gehen an den FM-1. Dort liegen sie im Flash und
   bleiben auch nach dem Ausschalten und nach Firmware-Updates erhalten.

Was der FM-1 spielt, ist die Welle aus diesen 64 Harmonischen, nicht die Datei selbst. Die Vorschau zeigt beides
übereinander. Sehr scharfe Kanten werden dabei etwas runder und bekommen kleine Überschwinger. Das ist bei jeder
bandbegrenzten Welle so, und dafür gibt es in hohen Lagen kein Aliasing.

## Dateinamen

`W12_glas.wav` geht in Platz 12 und heißt „glas“. Die Zahl nach dem `W` ist der Platz, der Rest nach `_` der Name.
Dateien ohne solchen Namen gehen der Reihe nach ab dem Platz, den du angibst.

## Die Webseite (`infekt-fm1.html`, Tab „Wavetables“)

1. `infekt-fm1.html` (oben in diesem Ordner) in **Chrome** oder **Edge** öffnen (Doppelklick), Tab „Wavetables“. Firefox und Safari können kein Web-MIDI mit SysEx.
2. **Verbinden** klicken und den MIDI-Zugriff erlauben (SysEx wird gebraucht). Bei mehreren MIDI-Geräten den FM-1 in der
   Liste wählen. Danach steht dort, welche Plätze schon eigene Wellen haben.
3. WAV-Dateien in das Feld ziehen. Für jede Datei siehst du eine Vorschau: grau das Original, farbig die Version aus
   64 Harmonischen. Platz und Name lassen sich noch ändern.
4. **An das FM-1 senden** schickt alle Wellen. Der FM-1 zeigt jede kurz an, z. B. „WAVE 12 LOADED glas“.
5. Unter **Wellen im FM-1**: einen Platz als WAV speichern („Save it as WAV“, Werkswellen auch), alle 62 speichern,
   einen Platz oder alle auf die Werkswelle zurücksetzen.

## Die Kommandozeile (`vfwaves.py`)

Benötigt Python 3 mit `numpy`, für MIDI zusätzlich `mido` und `python-rtmidi`, für die Vorschau `matplotlib`:

    pip install numpy mido python-rtmidi matplotlib

Beispiele:

    python3 vfwaves.py ports                              # MIDI-Anschlüsse anzeigen
    python3 vfwaves.py send W12_glas.wav                  # Platz 12 (aus dem Dateinamen)
    python3 vfwaves.py send saw.wav --slot 12 --name SAW1 # Platz und Name selbst angeben
    python3 vfwaves.py send a.wav b.wav c.wav --slot 20   # Plätze 20, 21, 22
    python3 vfwaves.py send meine_wellen/                 # jede W<nn>_<name>.wav im Ordner
    python3 vfwaves.py send W12_glas.wav --trim -2        # 2 dB leiser als die Regel
    python3 vfwaves.py list                               # welche Plätze eigene Wellen haben
    python3 vfwaves.py dump 12 --out wellen/              # Platz 12 als WAV zurückholen
    python3 vfwaves.py dump all --out wellen/             # alle 62 (eigene und Werkswellen)
    python3 vfwaves.py clear 12                           # Platz 12 wieder Werkswelle
    python3 vfwaves.py clear all                          # alle wieder Werkswellen
    python3 vfwaves.py plot W12_glas.wav                  # Vorschau als PNG (Original und 64 Harmonische)

`--port NAME` wählt den MIDI-Anschluss (ein Teil des Namens genügt). Ohne Angabe wird der FM-1 gesucht.
`--syx DATEI` schreibt die Nachrichten in eine `.syx`-Datei, statt sie zu senden, z. B. für ein anderes SysEx-Programm.
`decode ANTWORTEN.syx --out wellen/` macht aus aufgezeichneten Antworten des FM-1 (Dumps) WAV-Dateien.

Die zurückgeholten WAV-Dateien haben 2048 Samples pro Zyklus (32-Bit-Float, mit `--bits 16` 16 Bit) und lassen sich
wieder senden.

## Gut zu wissen

- Pro Welle braucht die Übertragung einen Bruchteil einer Sekunde. Das Werkzeug wartet jeweils auf die Bestätigung
  des FM-1 und vergleicht die Prüfsumme dessen, was im Flash steht.
- Während du spielst, kann geladen werden. Klingende Noten bekommen die neue Welle zwischen zwei Audio-Blöcken.
  Etwa jede 13. Welle löscht der FM-1 einen Flash-Sektor; dabei setzt der Ton kurz aus, wie beim Speichern eines
  Patches.
- Benutze immer nur ein Werkzeug zur gleichen Zeit (nicht USB und Bluetooth gleichzeitig).
- Über Bluetooth dauert alles etwas länger: Ein Dump braucht etwa 0,3 s.
- Die Wellen sind nicht Teil eines Patches. Wer einen Patch weitergibt, der eine eigene Welle nutzt, gibt die WAV-Datei
  dazu.
