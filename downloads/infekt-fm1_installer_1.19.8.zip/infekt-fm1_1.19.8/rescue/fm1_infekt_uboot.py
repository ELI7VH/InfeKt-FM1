#!/usr/bin/env python3
"""fm1_infekt_uboot: write an InfeKt-FM1 package's app area through the chip's own update mode (UBOOT).

For an FM-1 whose running firmware cannot update itself (InfeKt 1.11 or older on the newer flash part
UC25HQ80: it does not know the part and refuses every update). Uses fm1_rescue.py (same folder) for the
transport, the JieLi flash loader and the checks. What it does, in one session:
  1. loads the flash loader, checks chip key 980F and flash 856014 / B36014;
  2. reads and saves the whole flash as a backup;
  3. the head [0, 0x4000) of the FM-1 (its bootloader) is never written and must point the app at 0x4000;
  4. writes only the 4 KiB sectors in [0x4000, 0x93000) that differ from the package (the same range the
     package's own update loader writes); the device data above 0x93000 is never touched;
  5. a final full read must equal the expected image; then the FM-1 restarts.

  sudo ~/fm1-rescue/bin/python fm1_infekt_uboot.py infekt-fm1-1.13-multi-ble.fwsc            # check + backup
  sudo ~/fm1-rescue/bin/python fm1_infekt_uboot.py infekt-fm1-1.13-multi-ble.fwsc --write    # then write

Windows: no sudo (there is no root check there); the device needs the WinUSB driver (Zadig) while it is in
update mode, and `python` from the venv's Scripts folder (LIESMICH-RESCUE.txt in the installer's rescue/ folder).
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fm1_rescue as R  # noqa: E402

APP_END = 0x93000


def head_ok(flash):
    """the FM-1's own head: JLFS entries ENC'd; one of them must be app_dir_head at 0x4000"""
    for o in range(0x20, 0x200, 0x20):
        e = bytearray(flash[o:o + 0x20])
        R.enc(e)
        if e[16:28] == b"app_dir_head" and int.from_bytes(e[4:8], "little") == 0x4000:
            return True
    return False


def run(dev, image, loader, write, backup_dir):
    vendor, product = dev.inquiry()
    print(f"  device: {vendor} {product}", flush=True)
    if vendor != "WL82":
        raise R.Fail(f"not a WL82 UBOOT ({vendor!r})")
    dev.start_loader(loader)
    key, typ, fid = dev.chip()
    print(f"  chip key {key:04X}, flash type {typ}, id {fid:06X}", flush=True)
    if (key, typ) != (0x980F, 3) or fid not in R.FLASH_IDS:
        raise R.Fail("not the FM-1's chip and flash; nothing written")
    print("  reading the whole flash ...", flush=True)
    now = dev.read(0, R.FLASH_SIZE)
    path = os.path.join(backup_dir, time.strftime("fm1-backup-%Y%m%d-%H%M%S.bin"))
    with open(path, "wb") as f:
        f.write(now)
    print(f"  backup saved: {path}", flush=True)
    if not head_ok(now):
        raise R.Fail("the FM-1's head does not start an app at 0x4000: not writing; send this output")
    expect = now[:R.WRITE_MIN] + image[R.WRITE_MIN:APP_END] + now[APP_END:]
    diff = [a for a in range(R.WRITE_MIN, APP_END, R.SECTOR) if expect[a:a + R.SECTOR] != now[a:a + R.SECTOR]]
    print(f"  {len(diff)} of {(APP_END - R.WRITE_MIN) // R.SECTOR} firmware sectors differ", flush=True)
    if not write:
        print("  check passed. Nothing written: run again with --write.", flush=True)
        return
    for i, a in enumerate(reversed(diff)):          # high to low: the app's start is replaced last
        for attempt in range(3):
            try:
                dev.write_sector(a, expect[a:a + R.SECTOR], APP_END)
                break
            except R.Fail as e:
                if attempt == 2:
                    raise R.Fail(f"{e}; the FM-1 stays in update mode: run the script again")
        print(f"\r  writing {i + 1}/{len(diff)}", end="", flush=True)
    print("\n  final read ...", flush=True)
    final = dev.read(0, R.FLASH_SIZE)
    if final != expect:
        bad = [a for a in range(0, R.FLASH_SIZE, R.SECTOR) if final[a:a + R.SECTOR] != expect[a:a + R.SECTOR]]
        raise R.Fail("final read differs in " + " ".join(f"{a:#07x}" for a in bad) + "; run again with --write")
    print("  done. Restarting the FM-1 ...", flush=True)
    dev.run_app()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("package", help="an InfeKt-FM1 .fwsc (firmware/ folder of the installer)")
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--loader")
    ap.add_argument("--wait", type=float, default=120)
    args = ap.parse_args()
    try:
        image = R.package_flash_image(open(args.package, "rb").read())
        if len(image) != APP_END:
            raise R.Fail(f"{args.package}: not an InfeKt-FM1 package (flash entry {len(image):#x})")
        loader = R.get_loader(args.loader)
        if hasattr(os, "geteuid") and os.geteuid() != 0:   # (Linux, macOS; Windows has no geteuid: WinUSB, no root)
            raise R.Fail("run it with sudo")
        try:
            import usb.core
            import usb.util
        except ImportError:
            raise R.Fail("pyusb is missing: install pyusb and libusb-package in the venv (LIESMICH-RESCUE.txt)")
        for attempt in range(1, 6):
            bot = R.open_device(usb, args.wait)
            try:
                run(R.Uboot(bot), image, loader, args.write, os.path.dirname(os.path.abspath(args.package)))
                return 0
            except (R.Fail, usb.core.USBError) as e:
                print(f"\n  attempt {attempt}: {e}")
                if isinstance(e, R.Fail) and ("not writing" in str(e) or "nothing written" in str(e)):
                    return 1
            finally:
                try:
                    usb.util.dispose_resources(bot.dev)
                except Exception:
                    pass
        raise R.Fail("gave up; send this whole output")
    except R.Fail as e:
        print(f"fm1_infekt_uboot: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
