/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal */
/* fm1_input_tick (bsp/boards/fm1/fm1_input.h) against a model of the 74HC595 chain and the LED lines, with the GPIO
 * registers as memory and TIMER4 as a counter each register access advances. Built with FM1_SR_ONE 0 (every tick
 * shifts 16 bits) and 1 (one bit when the next column's word is the chain's moved on by one). Checked, over 2 200 ticks
 * with lit, dim and no LEDs, DIM HI and LO, and a breath:
 *   - every latch leaves the column's word in the outputs (0xFFFF less the column's bit, and bit 11 / 12 for
 *     columns 0 / 1), the LED lines dark at every latch;
 *   - the bits clocked a tick: 16, or with FM1_SR_ONE 1 on the ticks into any column but 2 (10 -> 0 too), 1;
 *   - a dim pulse: the lines lit | dim of its own column (never another's), its width FM1_LED_DIM_NS (or _LO_NS)
 *     -20 / +30 % (the 16-bit shift straddles it by a bit); a column without a dim LED has none;
 *   - a key held on every column is pressed after FM1_DEB_PRESS frames and let go after FM1_DEB_RELEASE, the same
 *     with both builds; the encoders' steps the same;
 *   - the bits clocked a frame (the cost the build saves) printed. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"
#include "fm1_time.h"
#include "fm1_gpio.h"
static uint32_t host_now;                          /* TIMER4 */
static volatile uint32_t host_reg[8][16];          /* port p, register r / 4 */
static uint32_t host_bus = 2u;                     /* TIMER4 ticks a register access (the device: ~75 ns, 1.8) */
static uint32_t host_ticks(void) { return host_now += 1u; }
#undef FM1_PR
#define FM1_PR(p, r) (*(host_now += host_bus, &host_reg[(p) & 7u][((r) / 4u) & 15u]))
#define fm1_ticks host_ticks
#define FM1_INPUT_NOW() host_now
static uint32_t sr_reg, sr_out, sr_clocks, latches, bad_latch, lines_now, lines_at_latch;
#define FM1_SR_CLOCK_TRACE(bit) (sr_reg = ((sr_reg << 1) | (bit)) & 0xFFFFu, sr_clocks++)
#define FM1_SR_LATCH_TRACE() (sr_out = sr_reg, latches++, lines_at_latch |= lines_now, nw_latch = nw)
/* the LED lines: every write with its time */
#define NW 16
static uint32_t lw[NW], lwt[NW], nw, nw_latch;
#define FM1_LED_TRACE(m) (lines_now = (m), nw < NW ? (lw[nw] = (m), lwt[nw++] = host_now) : 0u)
#include "fm1_input.h"

static int fails;
static void check(const char *what, int ok)
{
    if (!ok) {
        printf("FAIL %s\n", what);
        fails++;
    }
}
static uint32_t word_of(uint32_t c) { return 0xFFFFu ^ (1u << c) ^ (c < 2u ? 1u << (11u + c) : 0u); }

/* rows read by the scan: a key closed pulls its row low while its column is the one latched */
static uint32_t held_col = 99, held_rowbit;
static void rows_in(void)
{
    uint32_t col = 99, c, a = 0xFFFFFFFFu;
    for (c = 0; c < FM1_NCOL; c++)
        if (sr_out == word_of(c))
            col = c;
    if (col == held_col)                           /* row bit 1..4: PA5..PA8 */
        a &= ~(1u << (held_rowbit + 4u));
    host_reg[FM1_PA][FM1_IN / 4u] = a;
    host_reg[FM1_PB][FM1_IN / 4u] = 0xFFFFFFFFu;
}

static uint32_t clocks_frame;
/* one tick; returns its dim pulse width (TIMER4 ticks, 0: none) */
static uint32_t tick(void)
{
    uint32_t p = fm1__tick_col, n = p + 1u == FM1_NCOL ? 0u : p + 1u, c0 = sr_clocks, i, w = 0, pulse = 0, on = 0;
    nw = 0;
    lines_at_latch = 0;
    rows_in();
    fm1_input_tick();
    clocks_frame += sr_clocks - c0;
    check("the latched word is the column's", sr_out == word_of(n));
    check("the lines dark at the latch", lines_at_latch == 0u);
    check("16 bits, or 1 on a tick into any column but 2",
          sr_clocks - c0 == 16u || (FM1_SR_ONE && sr_clocks - c0 == 1u && n != 2u));
    for (i = 0; i < nw_latch; i++) {               /* the pulse: the first lit | dim write .. the next dark one */
        if (!on && (lw[i] & ~fm1_led[p])) {
            on = 1;
            w = lwt[i];
            check("the pulse is its column's", (lw[i] & ~(fm1_led[p] | fm1_led_dim[p] | fm1_led_breath[p])) == 0u);
        } else if (on && lw[i] == 0u) {
            pulse = lwt[i] - w;
            break;
        }
    }
    host_now += 100u * FM1_TICKS_PER_US;          /* the next tick 100 us later */
    return pulse;
}

static int run(const char *name, uint32_t lo)
{
    uint32_t i, c, T = lo ? FM1__DIM_T(FM1_LED_DIM_LO_NS) : FM1__DIM_T(FM1_LED_DIM_NS), nmin = ~0u, nmax = 0, frames;
    int f0 = fails;
    fm1_led_dim_level(lo);
    clocks_frame = 0;
    for (i = 0; i < 2200u; i++) {
        uint32_t p = fm1__tick_col, d = tick();
        if (i < 220u)                              /* (the shift's bits settle on their width first) */
            continue;
        if (fm1_led_dim[p] & ~fm1_led[p]) {
            if (d < nmin) nmin = d;
            if (d > nmax) nmax = d;
        } else
            check("no pulse without a dim LED", d == 0u);
    }
    frames = 2200u / FM1_NCOL;
    printf("%-40s pulse %u..%u ticks (target %u), %u bits a frame\n", name, nmin, nmax, T, clocks_frame / frames);
    (void)c;
    check("the pulse at least its target - 20 %", nmin == ~0u || nmin * 10u >= T * 8u);
    check("the pulse at most its target + 30 %", nmin == ~0u || nmax * 10u <= T * 13u);
    return fails == f0;
}

int main(void)
{
    uint32_t c, r;
    memset((void *)host_reg, 0, sizeof host_reg);
    fm1_input_init();
    check("init: all columns off", sr_out == 0xFFFFu);
    run("no LEDs", 0);
    for (c = 0; c < FM1_NCOL; c++)
        fm1_led_dim[c] = (uint8_t)(c & 1u ? 0x1Eu : 0x02u);
    fm1_led[3] = 0x04u;
    run("dim on every column, DIM HI", 0);
    run("dim on every column, DIM LO", 1);
    for (c = 0; c < FM1_NCOL; c++)
        fm1_led_dim[c] = (uint8_t)(c % 3u == 0u ? 0x08u : 0u);
    run("dim on every third column", 0);
    /* a key held on each column in turn: pressed after FM1_DEB_PRESS frames, let go after FM1_DEB_RELEASE */
    for (c = 0; c < FM1_NCOL; c++)
        for (r = 1; r < 5u; r++) {
            int id = FM1_KEYMAP[r][c], k, on_at = -1, off_at = -1;
            uint32_t bit;
            if (id < 0)
                continue;
            bit = id >= 14 ? 1u << (id - 14) : 1u << id;
            held_col = c;
            held_rowbit = r;
            for (k = 0; k < 11 * 6; k++) {
                tick();
                if (on_at < 0 && ((id >= 14 ? fm1_in.notes : fm1_in.buttons) & bit))
                    on_at = k;
            }
            held_col = 99;
            for (k = 0; k < 11 * 12; k++) {
                tick();
                if (off_at < 0 && !((id >= 14 ? fm1_in.notes : fm1_in.buttons) & bit))
                    off_at = k;
            }
            check("a held key is pressed within 3 frames", on_at >= 0 && on_at <= 3 * 11);
            check("a released key ends within 9 frames", off_at >= 0 && off_at <= 9 * 11);
            check("pressed exactly once", ((id >= 14 ? fm1_in.notes : fm1_in.buttons) & bit) == 0u);
        }
    printf("input_tick (FM1_SR_ONE %d): %s\n", FM1_SR_ONE, fails ? "FAILED" : "ok");
    return fails != 0;
}
