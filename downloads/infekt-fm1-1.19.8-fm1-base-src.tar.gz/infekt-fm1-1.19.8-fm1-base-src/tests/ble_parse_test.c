/* SPDX-License-Identifier: MPL-2.0 */
/* ble/midi/le_midi.c's packet parser (midi_parse, midi_len, cin_of) on the host: run_tests.sh cuts them out of the
 * file into $OUT/le_midi_parse.inc (from "static int midi_len" to the "MIDI out" section), this file gives them the
 * SysEx gatherer (le_sysex.h) and a ble_midi_receive that records. Real-time bytes between messages and inside a
 * running-status run, timestamps with and without a status, a message cut off.
 *   cc -I../ble/midi -I$OUT -o /tmp/t ble_parse_test.c && /tmp/t */
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "le_sysex.h"
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
static lsx_rx_t lsx;
static uint32_t got[64];
static int ngot, bad;
static jmp_buf endless;
static void ble_midi_receive(uint32_t pkt, uint32_t ts)
{
    (void)ts;
    if (ngot < 64) got[ngot] = pkt;
    if (++ngot > 1000) longjmp(endless, 1);   /* (a parse that never returns: before 1.19.2's fix, a clock before
                                               * a running-status message) */
}
#include "le_midi_parse.inc"
static void check(const char *what, const u8 *b, unsigned n, const uint32_t *want, int nw)
{
    ngot = 0;
    if (!setjmp(endless)) midi_parse(b, (u16)n, 0);
    if (ngot != nw || (nw && memcmp(got, want, sizeof *want * (unsigned)nw))) {
        int k;
        printf("FAIL %s: %d messages:", what, ngot);
        for (k = 0; k < ngot && k < 64; k++) printf(" %08x", got[k]);
        printf("\n");
        bad++;
    }
}
#define CHECK(what, in, ...) do { static const u8 b_[] = in; static const uint32_t w_[] = __VA_ARGS__; \
    check(what, b_, sizeof b_, w_, (int)(sizeof w_ / sizeof *w_)); } while (0)
#define B(...) {__VA_ARGS__}
int main(void)
{
    /* a note, a clock with its timestamp, the next note by running status with a timestamp, the next without */
    CHECK("a clock inside a running-status run", B(0x80, 0x81, 0x90, 60, 100, 0x82, 0xF8, 0x83, 62, 90, 64, 0),
          B(0x643c9009u, 0x0000f80fu, 0x5a3e9009u, 0x00409009u));
    /* a clock first, a control change, START, a program change, a clock last */
    CHECK("real time between messages", B(0x80, 0x81, 0xF8, 0x81, 0xB0, 1, 5, 0x82, 0xFA, 0x83, 0xC2, 7, 0x84, 0xF8),
          B(0x0000f80fu, 0x0501b00bu, 0x0000fa0fu, 0x0007c20cu, 0x0000f80fu));
    /* running status across two clocks; a note-off by its status */
    CHECK("two clocks, running status kept", B(0x80, 0x81, 0x90, 60, 100, 0x82, 0xF8, 0x82, 0xF8, 0x83, 60, 0,
                                               0x84, 0x80, 61, 0),
          B(0x643c9009u, 0x0000f80fu, 0x0000f80fu, 0x003c9009u, 0x003d8008u));
    /* cut off inside a message: what came before it only */
    CHECK("a message cut off", B(0x80, 0x81, 0x90, 60, 100, 0x82, 0xB0, 7),
          B(0x643c9009u));
    /* data bytes before any status: nothing */
    {
        static const u8 b[] = {0x80, 60, 100};
        check("no status yet", b, sizeof b, 0, 0);
    }
    if (!bad) printf("ok\n");
    return bad != 0;
}
