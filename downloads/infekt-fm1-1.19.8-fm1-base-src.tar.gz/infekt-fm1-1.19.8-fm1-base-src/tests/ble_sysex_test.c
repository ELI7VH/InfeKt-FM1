/* SPDX-License-Identifier: MPL-2.0 */
/* ble/midi/le_sysex.h on the host: frames of many lengths cut into packets (lsx_packet, MTUs 3..64) and gathered
 * again (lsx_body), with real-time bytes inside, a message too long, one cut off, one arriving before the last was
 * taken.   cc -I../ble/midi -o /tmp/t ble_sysex_test.c && /tmp/t */
#include <stdio.h>
#include <string.h>
#include "le_sysex.h"
static int bad;
static void check(const char *what, int ok) { if (!ok) { printf("FAIL %s\n", what); bad++; } }
static lsx_rx_t rx;
static int rts;
static void feed(const uint8_t *b, uint32_t len)   /* le_midi.c's parse, its SysEx part only */
{
    uint32_t i = 1;
    while (i < len) {
        if (rx.in) {
            int done; uint8_t rt;
            i = lsx_body(&rx, b, i, len, &done, &rt);
            if (rt) rts++;
            if (done == 2) return;       /* (the rest: ordinary MIDI) */
            continue;
        }
        if ((b[i] & 0x80) && i + 1 < len && b[i + 1] == 0xF0) { lsx_start(&rx); i += 2; continue; }
        return;
    }
}
int main(void)
{
    static uint8_t f[LSX_MAX + 2], p[64];
    uint32_t n, mtu, pos, len, k, packets;
    for (mtu = 3; mtu <= 64; mtu += 7)
        for (n = 2; n <= LSX_MAX + 2; n += 37) {
            f[0] = 0xF0; f[n - 1] = 0xF7;
            for (k = 1; k + 1 < n; k++) f[k] = (uint8_t)((k * 29 + n) & 0x7F);
            pos = 0; packets = 0; rx.ready = 0;
            while ((len = lsx_packet(p, mtu, f, n, &pos, 1234 + packets)) != 0) {
                check("a packet within the MTU", len <= mtu && len >= 2);
                feed(p, len);
                packets++;
            }
            check("all of it sent", pos == n);
            check("the message gathered whole", rx.ready && rx.n == n - 2 && !memcmp(rx.buf, f + 1, n - 2));
        }
    {   /* real time inside, as a sender may put it */
        const uint8_t a[] = {0x80, 0x81, 0xF0, 1, 2, 3, 0x82, 0xF8, 4, 5}, b[] = {0x80, 6, 7, 0x83, 0xF7, 0x84, 0x90, 60, 100};
        rx.ready = 0; rts = 0;
        feed(a, sizeof a); feed(b, sizeof b);
        check("a clock inside: taken out, the message whole", rx.ready && rx.n == 7 && rts == 1 && rx.buf[6] == 7);
    }
    {   /* one arriving before the last was taken: dropped; then one more after it was */
        const uint8_t a[] = {0x80, 0x81, 0xF0, 9, 9, 0x82, 0xF7};
        const uint8_t c[] = {0x80, 0x81, 0xF0, 1, 2, 0x82, 0xF7};
        rx.ready = 1; rx.n = 3; rx.buf[0] = 0x55;
        feed(a, sizeof a);
        check("the ready one kept", rx.ready && rx.n == 3 && rx.buf[0] == 0x55 && !rx.in);
        rx.ready = 0;
        feed(c, sizeof c);
        check("the next one taken", rx.ready && rx.n == 2 && rx.buf[1] == 2);
    }
    {   /* cut off by a note: dropped */
        const uint8_t a[] = {0x80, 0x81, 0xF0, 1, 2, 0x82, 0x90, 60, 100};
        rx.ready = 0;
        feed(a, sizeof a);
        check("cut off: none", !rx.ready && !rx.in);
    }
    {   /* too long: dropped */
        static uint8_t a[LSX_MAX + 10];
        rx.ready = 0;
        a[0] = 0x80; a[1] = 0x81; a[2] = 0xF0;
        for (k = 3; k < LSX_MAX + 7; k++) a[k] = 1;
        a[LSX_MAX + 7] = 0x82; a[LSX_MAX + 8] = 0xF7;
        feed(a, LSX_MAX + 9);
        check("too long: none", !rx.ready && !rx.in);
    }
    printf("%s ble_sysex_test\n", bad ? "FAIL" : "ok");
    return bad != 0;
}
