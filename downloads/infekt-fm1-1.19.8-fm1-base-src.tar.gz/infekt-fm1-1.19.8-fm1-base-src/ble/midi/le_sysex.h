/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal */
/* BLE MIDI SysEx both ways (le_midi.c), without the stack: tests/ble_sysex_test.c runs it on the host.
 *
 * In: the bytes between F0 and F7 of one SysEx message at a time, gathered over as many packets as it takes (BLE MIDI:
 * F0 after a timestamp, its data bytes, continued in the next packets right after their header, F7 after a timestamp;
 * real-time messages may come in between). A message ends ready (lsx_rx_t.ready) for the main loop, which takes it
 * and then clears ready; one arriving meanwhile is dropped (the sender waits for an answer), as is one longer than
 * LSX_MAX or cut off by another message.
 * Out: lsx_packet() fills the next packet of a whole F0 .. F7 frame: its header, a timestamp before F0 and before F7,
 * the data bytes in between with nothing else (the next packets carry only the header and data bytes). */
#ifndef LE_SYSEX_H
#define LE_SYSEX_H
#include <stdint.h>
#define LSX_MAX 320u                     /* bytes between F0 and F7 (a wave of the InfeKt-FM1's bank: 315; a single
                                          * dump: 265) */
typedef struct {
    uint8_t buf[LSX_MAX];
    uint16_t n;
    uint8_t in;                          /* 1 inside a message, 2 inside one being dropped, 0 not */
    uint8_t ready;                       /* a whole message in buf (n bytes) for the main loop */
    uint8_t over;                        /* longer than LSX_MAX: dropped */
} lsx_rx_t;
static inline void lsx_start(lsx_rx_t *r)
{
    r->in = r->ready ? 2u : 1u;          /* (the one ready not taken yet: this one dropped, that one kept) */
    if (r->in == 1u) {
        r->n = 0;
        r->over = 0;
    }
}
static inline void lsx_byte(lsx_rx_t *r, uint8_t b)
{
    if (r->in != 1u) return;
    if (r->n < LSX_MAX) r->buf[r->n++] = b;
    else r->over = 1;
}
static inline void lsx_end(lsx_rx_t *r)
{
    if (r->in == 1u && !r->over) r->ready = 1;
    r->in = 0;
}
/* a packet's body from b[i] (len bytes in all) inside a message: the index after what was taken; *done 1 when the
 * message ended (the rest is ordinary MIDI), 2 when something else cut it off at the returned index, *rt a real-time
 * status found inside (0 none: then nothing is returned after it) */
static inline uint32_t lsx_body(lsx_rx_t *r, const uint8_t *b, uint32_t i, uint32_t len, int *done, uint8_t *rt)
{
    *done = 0;
    *rt = 0;
    while (i < len) {
        if (!(b[i] & 0x80u)) { lsx_byte(r, b[i++]); continue; }
        if (b[i] == 0xF7u) { lsx_end(r); *done = 1; return i + 1u; }   /* (F7 without its timestamp: taken too) */
        if (i + 1u < len && b[i + 1u] == 0xF7u) { lsx_end(r); *done = 1; return i + 2u; }
        if (i + 1u < len && b[i + 1u] >= 0xF8u) { *rt = b[i + 1u]; return i + 2u; }
        if (i + 1u >= len) return i + 1u;   /* (a timestamp last in the packet: its byte follows in the next) */
        r->in = 0;                       /* (another message: this one unfinished, dropped) */
        *done = 2;
        return i;
    }
    return i;
}
/* the next packet of frame f (n bytes, F0 .. F7) from *pos into p (mtu bytes at most, >= 3): its length (0: nothing
 * left); *pos moves on. ms: the BLE MIDI timestamp (13 bits) */
static inline uint32_t lsx_packet(uint8_t *p, uint32_t mtu, const uint8_t *f, uint32_t n, uint32_t *pos, uint32_t ms)
{
    uint32_t k = 0, i = *pos;
    if (i >= n || mtu < 3u) return 0;
    p[k++] = (uint8_t)(0x80u | (ms >> 7 & 0x3Fu));
    if (i == 0u) {
        p[k++] = (uint8_t)(0x80u | (ms & 0x7Fu));
        p[k++] = f[i++];                 /* F0 */
    }
    while (i < n) {
        if (i == n - 1u) {               /* F7: its timestamp first */
            if (k + 2u > mtu) break;
            p[k++] = (uint8_t)(0x80u | (ms & 0x7Fu));
            p[k++] = f[i++];
        } else {
            if (k + 1u > mtu) break;
            p[k++] = f[i++] & 0x7Fu;
        }
    }
    *pos = i;
    return k;
}
#endif
