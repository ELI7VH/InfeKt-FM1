/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal (from CTL-1 and MONK-1) */
/* Velocity and pressure from the keys (touch.h): sense.c's readings with CTL-1's settings, tuned by playing, and
 * MONK-1's pressure. Part of the unity build (device/unity.c, host/plat_host.c) before app.c, for an app with
 * APP_TOUCH. */
#include "sense.c"

/* the scale, tuned by playing (CTL-1, 2026-10-15): the analog keys' driven reading for 127 and for 1, the curve's
 * exponent x 100 at curve 0; the top row's probe 0 / 43, its exponent 2.40 (TOUCH_TCURVE; an app's own:
 * touch_top_curve), a key's own ends from the app's calibration linear between them (touch_top_ends) */
#define TOUCH_FIRM 530u
#define TOUCH_LIGHT 896u
#define TOUCH_CURVE 70.0f

#define TOUCH_TCURVE 240u               /* the top row's exponent x 100 (touch_top_curve: an app's own) */
#define TOUCH_TCAL 100u                  /* a top key with ends of its own (touch_top_ends): linear between them */

static uint8_t touch_live;
static int8_t touch_c, touch_s;
static uint16_t touch_tc = TOUCH_TCURVE;
static uint32_t touch_held;              /* state: the sensed keys held (from the events) */
static uint8_t touch_v[NKEYS];

/* The top row's note waits for its peak (2026-11-14). The probe reads each top key once in three scan frames (~3.3 ms)
 * while the scan sees it closed, and the scan's press comes 1.1..2.2 ms after the contact: at the press the probe
 * has 0 or 1 readings, so a note took the key's previous velocity (no reading) or a peak still rising. The scan's
 * press is held back (touch_keys) until the probe's peak has stopped rising: TOUCH_TOP_WAIT readings at least, the
 * last of them not higher (one more if it was), TOUCH_TOP_NMAX at most; or the probe saw the key let go (a quick tap:
 * that press's final peak), or the scan let go of it, or TOUCH_TOP_MS went by with no reading (then TOUCH_TOP_NONE).
 * That peak is latched for the press: the note's velocity (touch_vel) and what an app's calibration reads
 * (touch_top_peak) are the same number, held or not. Added latency: ~3.3 ms after the probe's first reading at the
 * least, ~10 ms at most (TOUCH_TOP_NMAX). touch_top_wait(0): no wait, the live peak at the press (as before). */
#define TOUCH_TOP_WAIT 2u                /* probe readings at least */
#define TOUCH_TOP_NMAX 4u                /* at most (a peak still rising: taken then) */
#define TOUCH_TOP_MS 20u                 /* the scan's press with no probe reading this long: played without one */
#define TOUCH_TOP_NONE 64u               /* the velocity then (assumption: the middle, not the key's previous one) */
static uint8_t touch_tw = TOUCH_TOP_WAIT;
static uint8_t tt_st[SN_NTOP];           /* 0 up, 1 waiting for the peak (hidden from touch_keys), 2 latched */
static uint8_t tt_seq[SN_NTOP], tt_ok[SN_NTOP];   /* the probe's lseq at the press; a reading latched */
static uint16_t tt_pk[SN_NTOP], tt_acc[SN_NTOP];  /* the press's peak; the peaks of its ended bounces */
static uint32_t tt_t0[SN_NTOP], tt_hide, tt_pulse;   /* the scan's press then; the keys waiting; let go waiting */

/* Velo's settings, as MONK-1 and CTL-1 use them; the curve's exponent x 2 at +5, / 2 at -5 (the top row's too) */
static void touch_config(void)
{
    const float cs = fm_exp2f((float)touch_c * 0.2f);
    sn_cfg.touch = 900;
    sn_cfg.press = 400;
    sn_cfg.release = 600;
    sn_cfg.wait = 2;
    sn_cfg.v_lo = 0;
    sn_cfg.v_hi = 72;
    sn_cfg.vmax = 127;
    sn_cfg.at_range = 32;
    sn_cfg.drive = 2;
    sn_cfg.d_curve = (uint16_t)(TOUCH_CURVE * cs + 0.5f);
    sn_cfg.d_ceil = TOUCH_LIGHT;
    sn_cfg.d_floor = TOUCH_FIRM;
    sn_cfg.d_at_range = 64;
    sn_cfg.t_lo = 0;                     /* the top row's probe: */
    sn_cfg.t_hi = 43;                    /* firm presses pile up at 43..45 */
    sn_cfg.t_curve = (uint16_t)((float)touch_tc * cs + 0.5f);
    sn_cfg.t_cal_curve = (uint16_t)((float)TOUCH_TCAL * cs + 0.5f);
    sn_cfg.learn = 0;
}

void touch_on(int on)
{
    uint32_t i;
    on = on != 0;
    touch_config();
    if (on == touch_live)
        return;
    if (on) {
        sense_init(plat_analog_mask());  /* fresh key states: nothing was sampled while off */
        touch_config();
        sense_cal_reset();
    }
    touch_held = tt_hide = tt_pulse = 0;
    for (i = 0; i < SN_NTOP; i++)
        tt_st[i] = tt_ok[i] = 0;
    plat_sense(on);
    touch_live = (uint8_t)on;
}
int touch_is_on(void) { return touch_live; }
void touch_curve(int curve)
{
    touch_c = (int8_t)clamp(curve, -5, 5);
    touch_config();
}
void touch_sens(int sens) { touch_s = (int8_t)clamp(sens, -5, 5); }
void touch_top_curve(uint32_t x100)
{
    touch_tc = (uint16_t)(x100 ? (x100 > 1000u ? 1000u : x100) : TOUCH_TCURVE);
    touch_config();
}
void touch_top_ends(uint32_t key, uint32_t lo, uint32_t hi) { sense_top_ends(key - SN_TOP0, lo, hi); }
int touch_top_peak(uint32_t key)
{
    if (key < SN_TOP0 || key >= SN_NKEYS || !touch_live)
        return -1;
    if (touch_tw)                        /* the press's latched peak, held or let go (-1: none, or still waiting) */
        return tt_st[key - SN_TOP0] != 1u && tt_ok[key - SN_TOP0] ? tt_pk[key - SN_TOP0] : -1;
    return sn_probe[key].down ? sn_probe[key].peak : -1;
}
void touch_top_wait(uint32_t n) { touch_tw = (uint8_t)(n > TOUCH_TOP_NMAX ? TOUCH_TOP_NMAX : n); }

/* the top row's presses held back until the peak stops rising, then latched (above); every touch_poll */
static void touch_top_gate(void)
{
    uint32_t i, keys = plat_keys(), now = plat_ms();
    tt_pulse = 0;
    for (i = 0; i < SN_NTOP; i++) {
        const uint32_t key = SN_TOP0 + i, d = keys >> key & 1u;
        const sense_probe_t *p = &sn_probe[key];
        uint32_t ended, live, pk;
        if (!touch_tw || sense_is_analog(key)) {
            tt_st[i] = 0;
            continue;
        }
        if (tt_st[i] == 0u) {
            if (!d)
                continue;
            tt_st[i] = 1;
            tt_t0[i] = now;
            tt_seq[i] = p->lseq;
            tt_acc[i] = 0;
            tt_ok[i] = 0;
        }
        if (tt_st[i] == 2u) {
            if (!d)
                tt_st[i] = 0;
            continue;
        }
        ended = p->lseq != tt_seq[i];    /* (the probe saw it let go: a quick tap, or a bounce) */
        if (ended) {
            if (p->last > tt_acc[i])
                tt_acc[i] = p->last;
            tt_seq[i] = p->lseq;
            tt_ok[i] = 1;
        }
        live = p->down && p->n;
        pk = live && p->peak > tt_acc[i] ? p->peak : tt_acc[i];
        if ((live && ((p->n >= touch_tw && p->still) || p->n >= TOUCH_TOP_NMAX)) || (tt_ok[i] && !p->down) || !d
            || now - tt_t0[i] >= TOUCH_TOP_MS) {
            tt_ok[i] = (uint8_t)(tt_ok[i] || live);
            tt_pk[i] = (uint16_t)(tt_ok[i] ? pk : 0u);
            touch_v[key] = tt_ok[i] ? sense_probe_vel_of(key, pk) : (uint8_t)TOUCH_TOP_NONE;
            tt_st[i] = 2;
            if (!d) {                    /* (let go before: its press seen once, touch_keys) */
                tt_pulse |= 1u << key;
                tt_st[i] = 0;
            }
        }
    }
    tt_hide = 0;
    for (i = 0; i < SN_NTOP; i++)
        tt_hide |= (uint32_t)(tt_st[i] == 1u) << (SN_TOP0 + i);
}
uint8_t touch_top_vel(uint32_t key, uint32_t peak) { return key >= SN_TOP0 && key < SN_NKEYS ? sense_probe_vel_of(key, peak) : 0; }
int touch_sensed(uint32_t key) { return key < NKEYS && sense_is_analog(key); }

int touch_take(touch_ev_t *e)
{
    sense_ev_t s;
    while (touch_live && sense_take(&s)) {
        if (s.key >= NKEYS || (s.type != EV_ON && s.type != EV_OFF))
            continue;
        e->type = s.type == EV_ON ? TOUCH_PRESS : TOUCH_RELEASE;
        e->key = s.key;
        e->vel = s.vel ? s.vel : 1u;
        return 1;
    }
    return 0;
}

/* pressure, every 5 ms (MONK-1's): counted from where the key rests, not from where it landed (a key goes on
 * settling after the note), so the zero follows the driven reading down for P_SETTLE ms, then creeps after it,
 * and comes back up at once when the key is eased. The lean is the pill's resistance below its rest on a log
 * scale: P_DEAD of an octave is noise, P_SPAN more is 127. Smoothed over ~30 ms. */
#define P_SETTLE 250u                    /* ms */
#define P_DEAD 0.04f                     /* octaves of resistance */
#define P_SPAN(s) (0.8f * (1.0f - 0.85f * (s)))   /* 0..1: 0.8 .. 0.12 octave */
static float p_base[NKEYS], p_s[NKEYS];
static uint32_t p_t0[NKEYS], p_t;
static uint8_t p_on[NKEYS], p_val[NKEYS];
void touch_update(void)
{
    uint32_t i, now = plat_ms();
    float sens = 0.5f + (float)touch_s * 0.09f;
    if (!touch_live || now - p_t < 5u)
        return;
    p_t = now;
    for (i = 0; i < NKEYS; i++) {
        float d, lean, x;
        if (!sense_is_analog(i) || sn_key[i].st != SN_DOWN || !sn_key[i].dn) {
            p_on[i] = 0;
            p_s[i] = 0.0f;
            p_val[i] = 0;
            continue;
        }
        d = (float)(sn_key[i].d > SN_DBASE + 1u ? sn_key[i].d - SN_DBASE : 1u);
        if (!p_on[i]) {
            p_on[i] = 1;
            p_base[i] = d;
            p_t0[i] = now;
        }
        if (d > p_base[i])
            p_base[i] = d;                                     /* eased off: that is the rest now */
        else
            p_base[i] += (d - p_base[i]) * (now - p_t0[i] < P_SETTLE ? 0.25f : 0.0008f);
        lean = fm_log2f(p_base[i] / d);
        x = fm_clampf((lean - P_DEAD) / P_SPAN(sens), 0.0f, 1.0f);
        p_s[i] += (x - p_s[i]) * 0.17f;
        p_val[i] = (uint8_t)(p_s[i] * 127.0f + 0.5f);
    }
}
uint8_t touch_pressure(uint32_t key) { return key < NKEYS ? p_val[key] : 0; }
int touch_down(uint32_t key) { return key < NKEYS && touch_live && sn_key[key].st == SN_DOWN && sn_key[key].dn; }

void touch_poll(void)
{
    touch_ev_t e;
    while (touch_take(&e)) {
        if (e.type == TOUCH_PRESS) {
            touch_held |= 1u << e.key;
            touch_v[e.key] = e.vel;
        } else {
            touch_held &= ~(1u << e.key);
        }
    }
    if (touch_live)
        touch_top_gate();
    touch_update();
}
uint32_t touch_keys(void)
{
    uint32_t k = plat_keys(), mask = 0, i;
    if (!touch_live)
        return k;
    (void)i;
    mask = sn_analog & ((1u << NKEYS) - 1u);   /* (the analog rows' keys: one mask, not a loop a call: every main-loop pass) */
    return ((k & ~mask & ~tt_hide) | touch_held | tt_pulse | plat_remote_keys());   /* (remote keys: as pressed, no reading) */
}
uint8_t touch_vel(uint32_t key)
{
    if (key >= NKEYS)
        return 0;
    if (!sense_is_analog(key) && touch_live && touch_tw && key >= SN_TOP0 && key < SN_NKEYS) {
        const uint32_t i = key - SN_TOP0;   /* (the press's latched peak, through the ends as they are now) */
        if (tt_st[i] != 1u && tt_ok[i])
            return sense_probe_vel_of(key, tt_pk[i]);
        return touch_v[key] ? touch_v[key] : (uint8_t)TOUCH_TOP_NONE;
    }
    if (!sense_is_analog(key) && touch_live) {
        uint8_t v = sense_probe_velocity(key);
        if (v)
            touch_v[key] = v;
    }
    return touch_v[key] ? touch_v[key] : 100u;
}
uint8_t touch_vel_contact(uint32_t key) { return touch_live ? sense_probe_velocity(key) : 0; }

/* ---- the scan's readings, by key (from its interrupt) */
void app_key_sample(uint32_t key, uint32_t v, uint32_t ticks, int driven) { sense_sample(key, v, ticks, driven); }
int app_key_drive(uint32_t key) { return sense_want_drive(key); }
void app_key_probe(uint32_t key, uint32_t v, uint32_t pressed) { sense_probe(key, v, pressed); }
int app_key_led_ok(uint32_t key) { return key >= NKEYS || sn_key[key].st == SN_OPEN; }   /* open: its column may light */

#ifdef PLAT_HOST
/* ---- the host simulator: what the sensing would read from the FM-1 (CTL-1's and MONK-1's emulators): a
 * pulled-up sample under PRESS, a driven one at the depth the key's calibration maps to its velocity, then deeper
 * by the lean that touch_update reads as its pressure; the top seven keys through the probe */
#define TOUCH_PULL_DOWN 300u
static uint8_t h_vel[NKEYS];             /* 0 = up; else the velocity it lands with */
static float h_press[NKEYS];             /* 0..1 */
static uint16_t h_land[NKEYS];
static uint32_t h_t0[NKEYS];
/* the top row's probe as the host models it (2026-11-14; defaults: one reading at the press, then the same every
 * 3 ms, as before): the rise from the contact (TH_CONTACT, or the target if lower) to the target over th_rise ms,
 * th_noise counts either way on each reading, th_reads readings at most per press (then the probe sees it open while
 * the scan still holds it: a quick tap), the first reading th_phase ms after the press (255: a pseudo-random 0..3),
 * each key's own gain (x 100) and offset on the target (keys differ). Set by an app's host commands. */
#define TH_CONTACT 20u
static uint32_t th_rise, th_noise, th_reads = 255u, th_phase, th_rnd = 12345u;
static int32_t th_gain[SN_NTOP], th_off[SN_NTOP];
static uint16_t th_pk[SN_NTOP];
static uint32_t th_t0[SN_NTOP], th_n[SN_NTOP], th_next[SN_NTOP];
static uint32_t th_rand(void) { th_rnd = th_rnd * 1103515245u + 12345u; return th_rnd >> 16 & 0x7FFFu; }
static void th_read(uint32_t k, uint32_t now)   /* top key k: a probe reading at now */
{
    const uint32_t i = k - SN_TOP0, tgt = th_pk[i], c = tgt < TH_CONTACT ? tgt : TH_CONTACT;
    int32_t v = (int32_t)tgt;
    if (th_n[i] >= th_reads) {
        sense_probe(k, 100u, 0);
        return;
    }
    if (th_rise && now - th_t0[i] < th_rise)
        v = (int32_t)c + (int32_t)((float)(tgt - c) * (float)(now - th_t0[i]) / (float)th_rise + 0.5f);
    if (th_noise)
        v += (int32_t)(th_rand() % (2u * th_noise + 1u)) - (int32_t)th_noise;
    sense_probe(k, (uint32_t)(100 + (v > 0 ? v : 0)), 1);
    th_n[i]++;
}

static uint16_t touch_land_for(uint32_t k, uint32_t v)   /* sense_velocity_d, inverted */
{
    const sense_key_t *s = &sn_key[k];
    float r0 = (float)(s->dfloor > SN_DBASE ? s->dfloor - SN_DBASE : 1u), r1 = (float)(s->dceil - SN_DBASE);
    float c = TOUCH_CURVE * 0.01f, t;   /* (the key as measured: touch_curve does not change what it reads) */
    if (v >= 127u)
        return (uint16_t)(s->dfloor > 1u ? s->dfloor - 1u : 1u);
    t = 1.0f - fm_powf(((float)v - 1.0f) / 126.0f, 1.0f / c);
    return (uint16_t)(SN_DBASE + (uint32_t)(r0 * fm_powf(r1 / r0, t) + 0.5f));
}

void app_host_tick(void)                 /* every 2 ms: each sensed key's samples */
{
    uint32_t k, now = plat_ms();
    for (k = SN_TOP0; k < SN_NKEYS; k++)  /* (the top row: every 3 ms from the first reading) */
        if (!sense_is_analog(k) && h_vel[k] && (int32_t)(now - th_next[k - SN_TOP0]) >= 0) {
            th_read(k, now);
            th_next[k - SN_TOP0] = now + 3u;
        }
    if (now & 1u)
        return;
    for (k = 0; k < NKEYS; k++) {
        if (!sense_is_analog(k))
            continue;
        if (!h_vel[k]) {
            if (sn_key[k].st != SN_OPEN)
                sense_sample(k, 1023u, now * 24000u, 0);
            continue;
        }
        if (sn_key[k].st == SN_OPEN) {
            h_land[k] = touch_land_for(k, h_vel[k]);
            h_t0[k] = 0;
        }
        sense_sample(k, TOUCH_PULL_DOWN, now * 24000u, 0);
        if (sense_want_drive(k)) {
            uint32_t d = h_land[k];
            if (sn_key[k].st == SN_DOWN && !h_t0[k])
                h_t0[k] = now;
            if (h_t0[k] && now - h_t0[k] > P_SETTLE + 20u && p_on[k] && h_press[k] > 0.0f) {
                float lean = P_DEAD + h_press[k] * P_SPAN(0.5f + (float)touch_s * 0.09f);
                float r = p_base[k] / fm_exp2f(lean);
                d = SN_DBASE + (uint32_t)(r > 2.0f ? r : 2.0f);
            }
            sense_sample(k, d, now * 24000u, 1);
        }
    }
}

/* key k: vel 0 = up, else held, landed at vel; press 0..100 % */
void app_host_key(uint32_t k, uint32_t vel, uint32_t press)
{
    if (k >= NKEYS)
        return;
    h_vel[k] = (uint8_t)(vel > 127u ? 127u : vel);
    h_press[k] = (float)(press > 100u ? 100u : press) * 0.01f;
    if (sense_is_analog(k))
        return;
    if (vel) {                           /* the probe's rise above its open reading that maps to vel through the row's
                                          * default ends and curve (inverted; touch_curve and a key's own ends left out:
                                          * what the key reads, not what it plays) */
        uint32_t lo = sn_cfg.t_lo, hi = sn_cfg.t_hi > lo ? sn_cfg.t_hi : lo + 1u, i, t = k - SN_TOP0, ph;
        float c = (float)touch_tc * 0.01f;
        float x = fm_powf(((float)h_vel[k] - 1.0f) / 126.0f, 1.0f / c);
        int32_t pk = (int32_t)(lo + (uint32_t)((float)(hi - lo) * x + 0.5f));
        for (i = 0; i < 8u; i++)
            sense_probe(k, 100u, 0);
        if (t < SN_NTOP) {               /* (the key's own gain and offset, the model above) */
            pk = (pk * (th_gain[t] ? th_gain[t] : 100) + 50) / 100 + th_off[t];
            th_pk[t] = (uint16_t)(pk > 0 ? pk : 0);
            th_t0[t] = plat_ms();
            th_n[t] = 0;
            ph = th_phase == 255u ? th_rand() % 4u : th_phase;
            th_next[t] = th_t0[t] + ph;
            if (!ph) {
                th_read(k, th_t0[t]);
                th_next[t] = th_t0[t] + 3u;
            }
        }
    } else {
        sense_probe(k, 100u, 0);
    }
}
#endif
