/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal (from fm1-ble and fm1-ctl) */
/* A build with no radio (neither FM1B_BLE nor FM1B_WIFI): what radio.c gives the rest of the firmware, with nothing
 * behind it. Nothing from JieLi's libraries or the shim is linked. Part of the unity build (unity.c). */
static const uint8_t radio_quiet = 0;             /* the render never holds for the radio */
static const uint8_t radio_last_bad = 0;
static void radio_boot_note(void) {}
static void radio_clean_exit(void) {}
#include "ble_none.c"
/* the log (plat_log) without a radio: the app's lines, kept through a reset (.noinit) as radio.c's, read the same way
 * (main_fm1.c log_frame: fm1_remote.py log) */
#define NR_LOG_N 32
#define NR_LOG_MAGIC 0x4E4F4C31u                  /* "NOL1" */
static struct {
    uint32_t magic, w;
    char line[NR_LOG_N][40];
} nlog __attribute__((section(".noinit")));
void plat_log(const char *line)
{
    char *d;
    uint32_t i;
    if (nlog.magic != NR_LOG_MAGIC || nlog.w > 100000u) {
        nlog.magic = NR_LOG_MAGIC;
        nlog.w = 0;
    }
    d = nlog.line[nlog.w % NR_LOG_N];
    for (i = 0; i < 39u && line[i]; i++)
        d[i] = line[i] >= 32 && line[i] < 127 ? line[i] : ' ';
    d[i] = 0;
    nlog.w++;
}
const char *plat_ble_log_line(int back)
{
    if (nlog.magic != NR_LOG_MAGIC || back < 0 || (uint32_t)back >= nlog.w || back >= NR_LOG_N)
        return "";
    return nlog.line[(nlog.w - 1u - (uint32_t)back) % NR_LOG_N];
}
uint32_t plat_ble_log_total(void) { return nlog.magic == NR_LOG_MAGIC && nlog.w <= 100000u ? nlog.w : 0u; }
