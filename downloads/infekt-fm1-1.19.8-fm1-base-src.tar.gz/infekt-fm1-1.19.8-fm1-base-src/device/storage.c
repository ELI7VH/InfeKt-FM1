/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Changed for X0X and fm1-base: the object map is the app's (see below). */
/* Persistent storage on the SPI NOR.
 *
 * Every object has an A/B sector pair. A save goes to the copy that is not
 * the current one: erase the sector, program the payload (from offset 256),
 * then the 32-byte header at offset 0 last. The header is the commit record;
 * on load the valid copy with the highest seq wins, so a torn write leaves
 * the previous copy in charge.
 *
 * Flash access goes through three hooks (also used by the host test):
 *   st_read(off, dst, n)   st_erase(off)   st_prog(off, src, n)
 */
#define ST_MAGIC 0x30583058u                   /* "X0X0": never mistaken for a Felucca object */
#define ST_SECTOR 4096u
#define ST_PAYLOAD_OFF 256u
#define ST_PAYLOAD_MAX (ST_SECTOR - ST_PAYLOAD_OFF)

/* flash map: the app's (app.h APP_STORE_MAP, an offset per object, plat.h). Nothing between 0xE0000 and 0xFBFFF:
 * that is the update loader's staging area. The magic is X0X's; an app tells its own objects apart by its own magic. */
typedef struct {
    uint32_t magic;
    uint16_t type, slot;
    uint32_t seq, len, crc, rsv[2];
    uint32_t hcrc;
} st_hdr_t;

static int st_read(uint32_t off, void *dst, uint32_t n);
static int st_erase(uint32_t off);
static int st_prog(uint32_t off, const void *src, uint32_t n);

static uint32_t st_crc32(const void *p, uint32_t n)   /* zlib CRC-32, 4 bits per step */
{
    static const uint32_t T[16] = {
        0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
        0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};
    const uint8_t *b = p;
    uint32_t c = 0xFFFFFFFFu;
    while (n--) {
        c ^= *b++;
        c = (c >> 4) ^ T[c & 15u];
        c = (c >> 4) ^ T[c & 15u];
    }
    return ~c;
}

static uint32_t st_sector(uint32_t obj, uint32_t copy)  /* flash offset of copy A (0) / B (1) */
{
    static const uint32_t map[OBJ_NOBJ] = APP_STORE_MAP;
    return map[obj] + copy * ST_SECTOR;
}

static uint8_t st_buf[ST_PAYLOAD_MAX] __attribute__((aligned(4)));

/* an object held in st_buf with parts staged into it (st_stage), not written yet: -1 none. Written (one erase for many
 * parts) by st_flush: when another object is staged, before any other store call reads st_buf (st_current), or when
 * the app asks (plat_store_flush) */
static int st_held = -1, st_held_cur, st_held_err;
static uint32_t st_held_seq, st_held_len;
static int st_flush(void);

static int st_head(uint32_t obj, uint32_t copy, st_hdr_t *h)   /* commit record valid: 0 */
{
    if (st_read(st_sector(obj, copy), h, sizeof *h))
        return -1;
    if (h->magic != ST_MAGIC || h->type != obj || h->len > ST_PAYLOAD_MAX ||
        h->hcrc != st_crc32(h, sizeof *h - 4u))
        return -1;
    return 0;
}

static int st_body(uint32_t obj, uint32_t copy, const st_hdr_t *h)   /* payload -> st_buf, CRC ok: 0 */
{
    if (st_read(st_sector(obj, copy) + ST_PAYLOAD_OFF, st_buf, h->len) || st_crc32(st_buf, h->len) != h->crc)
        return -1;
    return 0;
}

/* the current copy: the valid one with the highest seq (A on a tie), -1 when
 * neither is valid. Headers first, so only the winner's payload is read (it
 * is left in st_buf); *h gets its header. */
static int st_current(uint32_t obj, st_hdr_t *h)
{
    st_hdr_t a, b;
    int va, vb;
    if (st_held >= 0) {
        int rc = st_flush();                         /* (st_buf is about to be read over: the parts held first) */
        if (rc) st_held_err = rc;
    }
    va = st_head(obj, 0, &a) == 0;
    vb = st_head(obj, 1, &b) == 0;
    if (vb && (!va || b.seq > a.seq)) {
        if (st_body(obj, 1, &b) == 0) {
            *h = b;
            return 1;
        }
        vb = 0;
    }
    if (va && st_body(obj, 0, &a) == 0) {
        *h = a;
        return 0;
    }
    if (vb && st_body(obj, 1, &b) == 0) {
        *h = b;
        return 1;
    }
    return -1;
}

/* load object into dst (up to max bytes); returns the length, or -1 (none; an empty object is none too: a restore
 * writes one for an object the backup did not have, backup.c) */
static int st_load(uint32_t obj, void *dst, uint32_t max)
{
    uint32_t i;
    st_hdr_t h;
    if (st_current(obj, &h) < 0 || !h.len)
        return -1;
    if (h.len > max)
        h.len = max;
    for (i = 0; i < h.len; i++)
        ((uint8_t *)dst)[i] = st_buf[i];
    return (int)h.len;
}

/* the object's length, or -1 (none) */
static int st_size(uint32_t obj)
{
    st_hdr_t h;
    if (st_held == (int)obj)
        return st_held_len ? (int)st_held_len : -1;
    if (st_current(obj, &h) < 0 || !h.len)
        return -1;
    return (int)h.len;
}

/* the object's first n bytes (a header, without a buffer for the whole): n, or -1 (none, or shorter than n) */
static int st_load_head(uint32_t obj, void *dst, uint32_t n)
{
    uint32_t i;
    st_hdr_t h;
    if (st_current(obj, &h) < 0 || !h.len || h.len < n)
        return -1;
    for (i = 0; i < n; i++)
        ((uint8_t *)dst)[i] = st_buf[i];
    return (int)n;
}

/* n bytes from off of the object (a part, without a buffer for the whole: a slot of a bank): n, or -1 (none, or
 * shorter than off + n) */
static int st_load_part(uint32_t obj, uint32_t off, void *dst, uint32_t n)
{
    uint32_t i;
    st_hdr_t h;
    if (st_held == (int)obj) {                       /* (held: as staged, from st_buf) */
        if (!st_held_len || off > st_held_len || n > st_held_len - off)
            return -1;
    } else if (st_current(obj, &h) < 0 || !h.len || off > h.len || n > h.len - off)
        return -1;
    for (i = 0; i < n; i++)
        ((uint8_t *)dst)[i] = st_buf[off + i];
    return (int)n;
}

static int st_commit(uint32_t obj, int cur, uint32_t seq, uint32_t len);

static int st_save(uint32_t obj, const void *src, uint32_t len)
{
    uint32_t off;
    int cur;
    st_hdr_t h;
    if (len > ST_PAYLOAD_MAX)
        return -1;
    cur = st_current(obj, &h);
    for (off = 0; off < len; off++)
        st_buf[off] = ((const uint8_t *)src)[off];    /* the driver wants RAM sources */
    return st_commit(obj, cur, cur < 0 ? 0u : h.seq, len);
}

/* n bytes at off into the object, the rest of it as it is (a slot of a bank, without a buffer for the whole): an
 * object shorter than off is first filled with zero bytes up to off; it grows to off + n if shorter. 0 = ok */
static int st_save_part(uint32_t obj, uint32_t off, const void *src, uint32_t n)
{
    uint32_t len, i;
    int cur;
    st_hdr_t h;
    if (off > ST_PAYLOAD_MAX || n > ST_PAYLOAD_MAX - off)
        return -1;
    cur = st_current(obj, &h);                       /* (the current copy in st_buf) */
    len = cur < 0 ? 0u : h.len;
    for (i = len; i < off; i++)
        st_buf[i] = 0;
    for (i = 0; i < n; i++)
        st_buf[off + i] = ((const uint8_t *)src)[i];
    if (off + n > len)
        len = off + n;
    return st_commit(obj, cur, cur < 0 ? 0u : h.seq, len);
}

/* as st_save_part, but the part only staged in st_buf: the object is written when it is flushed (st_flush: another
 * object staged, any other store call, plat_store_flush), so many parts of one object cost one erase (a bank of
 * patches arriving over USB). 0 = staged; an error of the flush of the object held before is returned here (the
 * part not staged), or by the next plat_store_flush when another call flushed it */
static int st_stage(uint32_t obj, uint32_t off, const void *src, uint32_t n)
{
    uint32_t i;
    int rc;
    if (off > ST_PAYLOAD_MAX || n > ST_PAYLOAD_MAX - off)
        return -1;
    if (st_held != (int)obj) {
        st_hdr_t h;
        int cur;
        if (st_held >= 0 && (rc = st_flush()) != 0)
            return rc;
        if (st_held_err) {
            rc = st_held_err;
            st_held_err = 0;
            return rc;
        }
        cur = st_current(obj, &h);                   /* (its current copy into st_buf) */
        st_held_cur = cur;
        st_held_seq = cur < 0 ? 0u : h.seq;
        st_held_len = cur < 0 ? 0u : h.len;
        st_held = (int)obj;
    }
    for (i = st_held_len; i < off; i++)
        st_buf[i] = 0;
    for (i = 0; i < n; i++)
        st_buf[off + i] = ((const uint8_t *)src)[i];
    if (off + n > st_held_len)
        st_held_len = off + n;
    return 0;
}

/* the object held (st_stage) written: 0 = done (or none held); an earlier flush's error is returned once */
static int st_flush(void)
{
    int obj = st_held, rc;
    if (obj < 0) {
        rc = st_held_err;
        st_held_err = 0;
        return rc;
    }
    st_held = -1;
    return st_commit((uint32_t)obj, st_held_cur, st_held_seq, st_held_len);
}

/* st_buf's len bytes into the copy that is not the current one (cur: st_current's), seq + 1, the header last */
static int st_commit(uint32_t obj, int cur, uint32_t seq, uint32_t len)
{
    uint32_t base, off;
    int rc;
    st_hdr_t h;
    base = st_sector(obj, cur == 0 ? 1u : 0u);       /* write the other copy */
    if ((rc = st_erase(base)) != 0)
        return rc;
    for (off = 0; off < len; off += 256u) {
        uint32_t n = len - off > 256u ? 256u : len - off;
        if ((rc = st_prog(base + ST_PAYLOAD_OFF + off, st_buf + off, n)) != 0)
            return rc;
    }
    h.magic = ST_MAGIC;
    h.type = (uint16_t)obj;
    h.slot = (uint16_t)(cur == 0 ? 1 : 0);
    h.seq = seq + 1u;
    h.len = len;
    h.crc = st_crc32(st_buf, len);
    h.rsv[0] = h.rsv[1] = 0xFFFFFFFFu;
    h.hcrc = st_crc32(&h, sizeof h - 4u);
    if ((rc = st_prog(base, &h, sizeof h)) != 0)       /* the commit record, last */
        return rc;
    {   /* read back: a write-protected or failing part must not report SAVED */
        st_hdr_t chk;
        uint32_t c = cur == 0 ? 1u : 0u;
        if (st_head(obj, c, &chk) || chk.seq != h.seq || st_body(obj, c, &chk))
            return -7;
    }
    return 0;
}
